// src/idb.ts
// IndexedDB storage wrapper for HomeVault.
// Database upgrades create missing stores without deleting existing data.

const DB_NAME = "homevault-db";
const DB_VERSION = 2;

const DOC_STORE = "documents";
const FILE_STORE = "files";
const SETTINGS_STORE = "settings";
const ACTIVITY_STORE = "activities";

export type LocalDocumentPermission = "private" | "family" | "public";

export interface IDBDocument {
  id: string;
  title: string;
  category: string;
  relatedPerson?: string;
  date?: string;
  expiryDate?: string;
  notes?: string;
  fileId?: string;
  fileName?: string;
  fileType?: string;
  fileSize?: number;
  userId?: string;
  permission?: LocalDocumentPermission;
  sharedWith?: string[];
  createdAt?: string;
}

export interface IDBSettings {
  id: string;
  vaultName: string;
  members: string[];
}

export interface IDBActivity {
  id?: number;
  type: "upload" | "download" | "delete" | "settings_save";
  documentId?: string;
  timestamp: number;
  details?: string;
}

interface StoredFile {
  docId: string;
  blob: Blob;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB is not supported by this browser."));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(DOC_STORE)) {
        db.createObjectStore(DOC_STORE, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(FILE_STORE)) {
        db.createObjectStore(FILE_STORE, { keyPath: "docId" });
      }
      if (!db.objectStoreNames.contains(SETTINGS_STORE)) {
        db.createObjectStore(SETTINGS_STORE, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains(ACTIVITY_STORE)) {
        db.createObjectStore(ACTIVITY_STORE, { keyPath: "id", autoIncrement: true });
      }
    };

    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => db.close();
      const required = [DOC_STORE, FILE_STORE, SETTINGS_STORE, ACTIVITY_STORE];
      const missing = required.filter((name) => !db.objectStoreNames.contains(name));
      if (missing.length) {
        db.close();
        reject(new Error(`Missing database stores: ${missing.join(", ")}.`));
        return;
      }
      resolve(db);
    };

    request.onerror = () => reject(request.error ?? new Error("Failed to open HomeVault database."));
    request.onblocked = () => console.warn("Database upgrade is blocked. Close other HomeVault tabs and retry.");
  });
}

function requestResult<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("IndexedDB request failed."));
  });
}

export async function getAllDocuments(): Promise<IDBDocument[]> {
  const db = await openDB();
  try {
    const tx = db.transaction(DOC_STORE, "readonly");
    return await requestResult(tx.objectStore(DOC_STORE).getAll()) as IDBDocument[];
  } finally { db.close(); }
}

export async function getDocument(id: string): Promise<IDBDocument | undefined> {
  const db = await openDB();
  try {
    const tx = db.transaction(DOC_STORE, "readonly");
    return await requestResult(tx.objectStore(DOC_STORE).get(id)) as IDBDocument | undefined;
  } finally { db.close(); }
}


export async function addDocument(
  doc: Omit<IDBDocument, "id">
): Promise<IDBDocument> {
  const db = await openDB();

  try {
    const id = `doc-${Date.now()}-${Math.random()
      .toString(36)
      .slice(2, 8)}`;

    const newDoc: IDBDocument = {
      ...doc,
      id,
      title: doc.title,
      category: doc.category,
    };

    const tx = db.transaction(DOC_STORE, "readwrite");
    const store = tx.objectStore(DOC_STORE);

    await requestResult(store.add(newDoc));

    return newDoc;
  } finally {
    db.close();
  }
}



export async function saveFileBlob(docId: string, file: File): Promise<void> {
  const db = await openDB();
  try {
    const tx = db.transaction(FILE_STORE, "readwrite");
    await requestResult(tx.objectStore(FILE_STORE).put({ docId, blob: file } satisfies StoredFile));
  } finally { db.close(); }
}

export async function getFileBlob(docId: string): Promise<Blob | undefined> {
  const db = await openDB();
  try {
    const tx = db.transaction(FILE_STORE, "readonly");
    const result = await requestResult(tx.objectStore(FILE_STORE).get(docId)) as StoredFile | undefined;
    return result?.blob;
  } finally { db.close(); }
}

export async function getSettings(): Promise<IDBSettings | undefined> {
  const db = await openDB();
  try {
    const tx = db.transaction(SETTINGS_STORE, "readonly");
    return await requestResult(tx.objectStore(SETTINGS_STORE).get("vault")) as IDBSettings | undefined;
  } finally { db.close(); }
}

export async function saveSettings(settings: { vaultName: string; members: string[] }): Promise<IDBSettings> {
  const db = await openDB();
  let data: IDBSettings;
  try {
    data = { id: "vault", vaultName: settings.vaultName, members: settings.members };
    const tx = db.transaction(SETTINGS_STORE, "readwrite");
    await requestResult(tx.objectStore(SETTINGS_STORE).put(data));
  } finally { db.close(); }
  await addActivity({ type: "settings_save", details: `Family settings updated for "${settings.vaultName}".` });
  return data;
}

export async function addActivity(activity: {
  type: IDBActivity["type"];
  documentId?: string;
  details?: string;
}): Promise<void> {
  const db = await openDB();
  try {
    const record: IDBActivity = { ...activity, timestamp: Date.now() };
    const tx = db.transaction(ACTIVITY_STORE, "readwrite");
    await requestResult(tx.objectStore(ACTIVITY_STORE).add(record));
  } finally { db.close(); }
}

export async function getActivities(): Promise<IDBActivity[]> {
  const db = await openDB();
  try {
    const tx = db.transaction(ACTIVITY_STORE, "readonly");
    const activities = await requestResult(tx.objectStore(ACTIVITY_STORE).getAll()) as IDBActivity[];
    return activities.sort((a, b) => b.timestamp - a.timestamp);
  } finally { db.close(); }
}

export async function deleteDocument(id: string): Promise<void> {
  const db = await openDB();
  try {
    const tx = db.transaction([DOC_STORE, FILE_STORE], "readwrite");
    tx.objectStore(DOC_STORE).delete(id);
    tx.objectStore(FILE_STORE).delete(id);
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("Could not delete document."));
      tx.onabort = () => reject(tx.error ?? new Error("Document deletion was cancelled."));
    });
  } finally { db.close(); }
  await addActivity({ type: "delete", documentId: id, details: `Document ${id} was deleted.` });
}

export async function countDocuments(): Promise<number> {
  const db = await openDB();
  try {
    const tx = db.transaction(DOC_STORE, "readonly");
    return await requestResult(tx.objectStore(DOC_STORE).count());
  } finally { db.close(); }
}

export async function getAllFilesSize(): Promise<number> {
  const db = await openDB();
  try {
    const tx = db.transaction(FILE_STORE, "readonly");
    const files = await requestResult(tx.objectStore(FILE_STORE).getAll()) as StoredFile[];
    return files.reduce((total, item) => total + (item.blob?.size ?? 0), 0);
  } finally { db.close(); }
}
