// src/lib/appwrite.ts
// Browser-safe Appwrite configuration. Never put server API keys here.
import {
  Client,
  Account,
  Databases,
  Storage,
  Teams,
  AppwriteException,
  ID,
  Permission,
  Role,
  Query,
} from "appwrite";

const env = import.meta.env;
const endpoint = (env.VITE_APPWRITE_ENDPOINT ?? "").trim();
const projectId = (env.VITE_APPWRITE_PROJECT_ID ?? "").trim();
const databaseId = (env.VITE_APPWRITE_DATABASE_ID ?? "homevault-db").trim();
const documentsCollectionId = (env.VITE_APPWRITE_COLLECTION_DOCUMENTS ?? "documents").trim();
const settingsCollectionId = (env.VITE_APPWRITE_COLLECTION_SETTINGS ?? "vault_settings").trim();
const activitiesCollectionId = (env.VITE_APPWRITE_COLLECTION_ACTIVITIES ?? "activities").trim();
const storageBucketId = (env.VITE_APPWRITE_BUCKET_ID ?? "homevault-files").trim();
const familyTeamId = (env.VITE_APPWRITE_TEAM_ID ?? "").trim();

export const isAppwriteConfigured = Boolean(endpoint && projectId);
export const client = new Client();
if (isAppwriteConfigured) client.setEndpoint(endpoint).setProject(projectId);

export const account = new Account(client);
export const databases = new Databases(client);
export const storage = new Storage(client);
export const teams = new Teams(client);
export { AppwriteException, ID, Permission, Role, Query };

export const appwriteConfig = {
  endpoint,
  projectId,
  databaseId,
  documentsCollectionId,
  settingsCollectionId,
  activitiesCollectionId,
  storageBucketId,
  familyTeamId,
};
