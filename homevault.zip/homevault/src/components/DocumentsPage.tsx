
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, DocumentItem } from "../api";
import { useAuth } from "../contexts/AuthContext";
import NavBar from "./NavBar";

// Format file size
const formatSize = (bytes?: number) => {
  if (bytes === undefined) return "-";
  if (bytes < 1024) return `${bytes} B`;

  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;

  const mb = kb / 1024;
  return `${mb.toFixed(1)} MB`;
};

const DocumentsPage: React.FC = () => {
  const { user } = useAuth();
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("");

  useEffect(() => {
    const fetchDocuments = async () => {
      try {
        const docs = await api.getDocuments(user?.id);
        const cats = await api.getCategories();

        setDocuments(docs);
        setCategories(cats);
      } catch (error) {
        console.error("Failed to load documents:", error);
      }
    };

    fetchDocuments();
  }, [user?.id]);


  const filtered = documents.filter((doc) => {
    const matchesTitle = (doc.title ?? "")
      .toLowerCase()
      .includes(searchTerm.toLowerCase());

    const matchesCategory = filterCategory
      ? doc.category === filterCategory
      : true;

    return matchesTitle && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-navy text-white">
      <NavBar />

      <main className="container mx-auto max-w-6xl px-4 py-8">
        <h2 className="mb-6 text-3xl font-bold text-yellow-300">
          All Documents
        </h2>

        {/* Search and category filter */}
        <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center">
          <input
            type="text"
            placeholder="Search by title..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            aria-label="Search documents by title"
            className="w-full rounded-lg border border-slate-500 bg-slate-800 px-4 py-3 text-white placeholder-slate-400 focus:border-yellow-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 md:flex-1"
          />

          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            aria-label="Filter documents by category"
            className="w-full rounded-lg border border-slate-500 bg-slate-800 px-4 py-3 text-white focus:border-yellow-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 md:w-64"
          >
            <option value="">All Categories</option>

            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          <Link
            to="/dashboard"
            className="font-semibold text-yellow-300 hover:text-yellow-100 hover:underline"
          >
            ← Back to Dashboard
          </Link>
        </div>

        {/* Document list */}
        {filtered.length === 0 ? (
          <div className="rounded-xl border border-slate-600 bg-slate-800 p-8 text-center">
            <p className="text-lg font-semibold text-white">
              No documents found
            </p>
            <p className="mt-2 text-slate-300">
              Try a different search term or category.
            </p>
          </div>
        ) : (
          <ul className="space-y-4">
            {filtered.map((doc) => (
              <li
                key={doc.id}
                className="flex flex-col gap-4 rounded-xl border border-slate-600 bg-slate-800 p-5 shadow-lg transition-colors hover:border-yellow-400 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <h3 className="break-words text-lg font-bold text-yellow-300">
                    {doc.title}
                  </h3>

                  <p className="mt-1 break-words text-sm text-slate-200">
                    {doc.category}
                    {doc.fileSize !== undefined &&
                      ` | ${formatSize(doc.fileSize)}`}
                    {doc.date && ` — ${doc.date}`}
                    {doc.expiryDate &&
                      ` (expires ${doc.expiryDate})`}
                  </p>
                </div>

                <Link
                  to={`/documents/${doc.id}`}
                  className="inline-block shrink-0 font-semibold text-yellow-300 hover:text-yellow-100 hover:underline"
                >
                  View Details →
                </Link>
              </li>
            ))}
          </ul>
        )}

        <p className="mt-6 rounded-lg border border-slate-700 bg-slate-900/50 p-4 text-sm leading-6 text-slate-300">
          <strong className="text-yellow-300">Note:</strong>{" "}
          This list may contain sample documents. Verify that your API
          stores uploaded files persistently before relying on them.
        </p>
      </main>
    </div>
  );
};

export default DocumentsPage;
