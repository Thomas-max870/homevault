// src/components/PublicRoute.tsx
// Wraps public auth pages (login, register, forgot-password, reset-password).
// Redirects authenticated users away to the dashboard (or /verify-email if unverified).

import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import LoadingScreen from "./LoadingScreen";

interface PublicRouteProps {
  children: React.ReactNode;
}

const PublicRoute: React.FC<PublicRouteProps> = ({ children }) => {
  const { user, loading } = useAuth();

  // Show loading screen while checking session.
  if (loading) {
    return <LoadingScreen />;
  }

  // Already authenticated
  if (user) {
    if (user.emailVerified) {
      return <Navigate to="/dashboard" replace />;
    }
    return <Navigate to="/verify-email" replace />;
  }

  return <>{children}</>;
};

export default PublicRoute;
