// src/components/NavBar.tsx
import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

const links = [
  { to: "/dashboard", label: "Dashboard" },
  { to: "/upload", label: "Upload" },
  { to: "/documents", label: "Documents" },
  { to: "/categories", label: "Categories" },
  { to: "/activity", label: "Activity" },
  { to: "/settings", label: "Settings" },
];

const NavBar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login", { replace: true });
    } catch {
      // Even if logout fails, redirect to login.
      navigate("/login", { replace: true });
    }
  };

  return (
    <nav className="bg-navy text-white py-3">
      <div className="container flex justify-between items-center">
        <h1 className="text-xl font-semibold">HomeVault</h1>
        <div className="flex items-center gap-6">
          <ul className="flex space-x-4">
            {links.map((link) => (
              <li key={link.to}>
                <NavLink
                  to={link.to}
                  className={({ isActive }) =>
                    isActive ? "text-gold underline" : "hover:text-gold transition-colors"
                  }
                >
                  {link.label}
                </NavLink>
              </li>
            ))}
          </ul>

          {/* User info and logout */}
          {user && (
            <div className="flex items-center gap-3 border-l border-white/20 pl-4">
              <span className="text-sm text-slate-300" title={user.email}>
                {user.name || user.email}
              </span>
              <NavLink
                to="/change-password"
                className={({ isActive }) =>
                  isActive ? "text-gold underline text-sm" : "text-sm text-slate-300 hover:text-gold transition-colors"
                }
                title="Change Password"
              >
                Password
              </NavLink>
              <button
                onClick={handleLogout}
                className="rounded bg-white/10 px-3 py-1.5 text-sm font-medium text-white transition-colors hover:bg-white/20"
                title="Sign out"
              >
                Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
