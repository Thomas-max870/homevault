// src/components/auth/ForgotPasswordPage.tsx
// Password recovery request page connected to Appwrite createRecovery API.

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { AuthNotConfiguredError } from "../../authBackend";
import AuthCard from "./AuthCard";

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const ForgotPasswordPage: React.FC = () => {
  const { sendPasswordRecovery, isConfigured } = useAuth();

  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!email.trim()) {
      newErrors.email = "Email address is required.";
    } else if (!emailRegex.test(email.trim())) {
      newErrors.email = "Please enter a valid email address.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    setErrors({});

    if (!validate()) return;

    setSubmitting(true);

    try {
      await sendPasswordRecovery(email.trim());
      // Only set success after Appwrite API call succeeds
      setSubmitted(true);
    } catch (err) {
      if (err instanceof AuthNotConfiguredError) {
        setErrors({ form: err.message });
      } else if (err instanceof Error) {
        setErrors({
          form: err.message || "Failed to send recovery email. Please try again.",
        });
      } else {
        setErrors({
          form: "Failed to send recovery email. Please check your Appwrite setup.",
        });
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthCard
      title="Forgot Password"
      subtitle="Enter your email to receive a password reset link"
    >
      {/* Provider not configured notice */}
      {!isConfigured && !submitted && (
        <div className="mb-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
          <strong>Setup required:</strong> Appwrite authentication is not configured.
          Password recovery requires valid <code className="font-mono text-xs">VITE_APPWRITE_ENDPOINT</code> and{" "}
          <code className="font-mono text-xs">VITE_APPWRITE_PROJECT_ID</code>.
        </div>
      )}

      {submitted ? (
        <div className="text-center">
          <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
            <svg
              className="h-8 w-8 text-green-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900">
            Recovery email sent
          </h3>
          <p className="mb-6 text-sm text-gray-600">
            A password reset link has been dispatched to{" "}
            <strong className="text-gray-900">{email}</strong> via Appwrite.
            Please check your inbox (and spam folder) and click the link to reset your password.
          </p>
          <Link
            to="/login"
            className="inline-block rounded-lg bg-gold px-6 py-3 font-bold text-navy transition-colors hover:bg-yellow-400"
          >
            ← Back to Sign In
          </Link>
        </div>
      ) : (
        <>
          <form onSubmit={handleSubmit} className="space-y-4" noValidate>
            {/* Form-level error */}
            {errors.form && (
              <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-700">
                {errors.form}
              </div>
            )}

            {/* Email */}
            <div>
              <label
                htmlFor="forgot-email"
                className="mb-1 block text-sm font-medium text-gray-700"
              >
                Email address <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                id="forgot-email"
                name="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                autoComplete="email"
                disabled={submitting}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={
                  errors.email ? "forgot-email-error" : undefined
                }
                className={`w-full rounded-lg border px-4 py-3 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-gold ${
                  errors.email ? "border-red-400" : "border-gray-300"
                }`}
              />
              {errors.email && (
                <p
                  id="forgot-email-error"
                  className="mt-1 text-sm text-red-500"
                >
                  {errors.email}
                </p>
              )}
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={submitting}
              className="w-full rounded-lg bg-gold px-4 py-3 font-bold text-navy transition-colors hover:bg-yellow-400 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {submitting ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-navy/30 border-t-navy" />
                  Requesting reset link…
                </span>
              ) : (
                "Send Reset Link"
              )}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-gray-500">
            <Link
              to="/login"
              className="font-medium text-navy hover:text-gold hover:underline"
            >
              ← Back to Sign In
            </Link>
          </p>
        </>
      )}
    </AuthCard>
  );
};

export default ForgotPasswordPage;
