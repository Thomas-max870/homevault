// src/components/auth/LoginPage.tsx
// HomeVault login page connected to Appwrite email/password authentication.

import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { AuthNotConfiguredError } from "../../authBackend";
import AuthCard from "./AuthCard";
import PasswordInput from "./PasswordInput";

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isConfigured } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  // Where to redirect after successful login.
  const from = (location.state as { from?: string })?.from || "/dashboard";

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!email.trim()) {
      newErrors.email = "Email address is required.";
    } else if (!emailRegex.test(email.trim())) {
      newErrors.email = "Please enter a valid email address.";
    }

    if (!password) {
      newErrors.password = "Password is required.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    setErrors({});

    if (!validate()) return;

    setSubmitting(true);

    try {
      await login(email.trim(), password, remember);
      navigate(from, { replace: true });
    } catch (err) {
      if (err instanceof AuthNotConfiguredError) {
        setErrors({ form: err.message });
      } else if (err instanceof Error) {
        setErrors({
          form: err.message || "Invalid email or password. Please try again.",
        });
      } else {
        setErrors({
          form: "Invalid email or password. Please try again.",
        });
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthCard title="Sign In" subtitle="Access your family document vault">
      {/* Provider not configured notice */}
      {!isConfigured && (
        <div className="mb-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
          <strong>Setup required:</strong> Appwrite authentication is not configured.
          Please set <code className="rounded bg-amber-100 px-1 font-mono text-xs">VITE_APPWRITE_ENDPOINT</code> and{" "}
          <code className="rounded bg-amber-100 px-1 font-mono text-xs">VITE_APPWRITE_PROJECT_ID</code> in your{" "}
          <code className="font-mono text-xs">.env</code> file.
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        {/* Form-level error */}
        {errors.form && (
          <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-700">
            {errors.form}
          </div>
        )}

        {/* Email */}
        <div>
          <label
            htmlFor="login-email"
            className="mb-1 block text-sm font-medium text-gray-700"
          >
            Email address <span className="text-red-500">*</span>
          </label>
          <input
            type="email"
            id="login-email"
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
            autoComplete="email"
            disabled={submitting}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "login-email-error" : undefined}
            className={`w-full rounded-lg border px-4 py-3 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-gold ${
              errors.email ? "border-red-400" : "border-gray-300"
            }`}
          />
          {errors.email && (
            <p id="login-email-error" className="mt-1 text-sm text-red-500">
              {errors.email}
            </p>
          )}
        </div>

        {/* Password */}
        <PasswordInput
          id="login-password"
          name="password"
          label="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter your password"
          error={errors.password}
          required
          autoComplete="current-password"
          disabled={submitting}
        />

        {/* Remember me and Forgot Password */}
        <div className="flex items-center justify-between">
          <label className="flex items-center gap-2 text-sm text-gray-600">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              disabled={submitting}
              className="h-4 w-4 rounded border-gray-300 text-gold focus:ring-gold"
            />
            Remember me
          </label>
          <Link
            to="/forgot-password"
            className="text-sm font-medium text-navy hover:text-gold hover:underline"
          >
            Forgot password?
          </Link>
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-lg bg-gold px-4 py-3 font-bold text-navy transition-colors hover:bg-yellow-400 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-navy/30 border-t-navy" />
              Signing in…
            </span>
          ) : (
            "Sign In"
          )}
        </button>
      </form>

      {/* Register link */}
      <p className="mt-6 text-center text-sm text-gray-500">
        Don&apos;t have an account?{" "}
        <Link
          to="/register"
          className="font-medium text-navy hover:text-gold hover:underline"
        >
          Create Account
        </Link>
      </p>
    </AuthCard>
  );
};

export default LoginPage;
