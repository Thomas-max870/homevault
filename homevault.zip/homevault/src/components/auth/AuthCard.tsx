// src/components/auth/AuthCard.tsx
// Reusable card wrapper for all authentication pages.
// Navy background page with a centered light card.

import React from "react";
import { Link } from "react-router-dom";

interface AuthCardProps {
  /** Card title displayed below the branding. */
  title: string;
  /** Optional subtitle or description. */
  subtitle?: string;
  children: React.ReactNode;
}

const AuthCard: React.FC<AuthCardProps> = ({ title, subtitle, children }) => {
  return (
    <div className="flex min-h-screen items-center justify-center bg-navy px-4 py-12">
      <div className="w-full max-w-md">
        {/* Branding */}
        <div className="mb-8 text-center">
          <Link to="/login" className="inline-block no-underline">
            <h1 className="text-4xl font-bold tracking-tight text-gold">
              HomeVault
            </h1>
            <p className="mt-1 text-sm text-slate-300">
              Private Family Document Manager
            </p>
          </Link>
        </div>

        {/* Card */}
        <div className="rounded-2xl bg-white p-8 shadow-xl">
          <h2 className="mb-1 text-center text-2xl font-bold text-gray-900">
            {title}
          </h2>
          {subtitle && (
            <p className="mb-6 text-center text-sm text-gray-500">
              {subtitle}
            </p>
          )}
          {!subtitle && <div className="mb-6" />}
          {children}
        </div>
      </div>
    </div>
  );
};

export default AuthCard;
