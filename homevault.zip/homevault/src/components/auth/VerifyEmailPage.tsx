// src/components/auth/VerifyEmailPage.tsx
// Email verification page connected to Appwrite email verification API.
// Handles both the post-registration notice and token callbacks (?userId=...&secret=...).

import React, { useState, useEffect, useRef } from "react";
import { Link, useSearchParams, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { AuthNotConfiguredError, isUserAlreadyVerifiedError } from "../../authBackend";
import AuthCard from "./AuthCard";

const VerifyEmailPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { user, completeEmailVerification, sendEmailVerification, isConfigured } = useAuth();

  // Read the userId and secret query parameters from the verification URL
  const userId = searchParams.get("userId")?.trim() || "";
  const secret = searchParams.get("secret")?.trim() || "";
  const hasToken = Boolean(userId && secret);

  // Router state passed from register page or ProtectedRoute
  const routerState = (location.state as {
    email?: string;
    verificationSent?: boolean;
    emailError?: string;
    unverified?: boolean;
  }) || {};

  const registeredEmail = routerState.email || user?.email || "";
  const verificationSent = routerState.verificationSent ?? true;
  const emailError = routerState.emailError;
  const redirectedBecauseUnverified = routerState.unverified || Boolean(user && !user.emailVerified);

  const [verifying, setVerifying] = useState(false);
  const [verified, setVerified] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Resend state (only triggered manually, never automatically on page load)
  const [resending, setResending] = useState(false);
  const [resendStatus, setResendStatus] = useState<string | null>(null);

  // In-flight request trackers to prevent duplicate calls in React StrictMode
  // and prevent consuming the token twice.
  const inFlightTokenKeyRef = useRef<string | null>(null);
  const inFlightPromiseRef = useRef<Promise<void> | null>(null);

  // Process verification when both userId and secret parameters exist
  useEffect(() => {
    // Requirement: Do not call updateVerification without both parameters
    if (!userId || !secret) {
      return;
    }

    const tokenKey = `${userId}:${secret}`;
    let isCurrent = true;

    setVerifying(true);
    setError(null);

    // Reuse the in-flight promise if the effect runs multiple times (e.g. React 18 StrictMode)
    if (inFlightTokenKeyRef.current !== tokenKey || !inFlightPromiseRef.current) {
      inFlightTokenKeyRef.current = tokenKey;
      inFlightPromiseRef.current = completeEmailVerification(userId, secret);
    }

    inFlightPromiseRef.current
      .then(() => {
        if (isCurrent) {
          setVerified(true);
          setError(null);
        }
      })
      .catch((err: unknown) => {
        if (isCurrent) {
          // Requirement: Handle HTTP 409 responses properly (user is already verified)
          if (isUserAlreadyVerifiedError(err)) {
            setVerified(true);
            setError(null);
          } else if (err instanceof AuthNotConfiguredError) {
            setError(err.message);
          } else if (err instanceof Error) {
            setError(err.message || "Verification failed. The link may be expired or invalid.");
          } else {
            setError("Verification failed. The link may be expired or invalid.");
          }
        }
      })
      .finally(() => {
        if (isCurrent) {
          setVerifying(false);
        }
      });

    return () => {
      isCurrent = false;
    };
  }, [userId, secret, completeEmailVerification]);

  // Requirement: Do not automatically resend verification emails when the page loads.
  // Resend is only triggered on manual button click by an authenticated user.
  const handleResend = async () => {
    if (!user) {
      setResendStatus("Please sign in first to request a new verification email.");
      return;
    }

    setResending(true);
    setResendStatus(null);
    try {
      await sendEmailVerification();
      setResendStatus("A new verification email has been sent. Please check your inbox.");
    } catch (err) {
      if (err instanceof Error) {
        setResendStatus(`Failed to send verification email: ${err.message}`);
      } else {
        setResendStatus("Failed to send verification email. Please try again later.");
      }
    } finally {
      setResending(false);
    }
  };

  // ──────────────────────────────────────────────
  // State 1: Verifying token from email link
  // ──────────────────────────────────────────────
  if (hasToken && verifying) {
    return (
      <AuthCard title="Verifying Email" subtitle="Confirming your address with Appwrite">
        <div className="text-center py-6">
          <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-4 border-gold/30 border-t-gold" />
          <p className="text-sm text-gray-600">
            Verifying your email address…
          </p>
        </div>
      </AuthCard>
    );
  }

  // ──────────────────────────────────────────────
  // State 2: Verification confirmed by Appwrite (or already verified via 409)
  // ──────────────────────────────────────────────
  if (verified) {
    return (
      <AuthCard title="Email Verified" subtitle="Your account is active">
        <div className="text-center">
          <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
            <svg
              className="h-8 w-8 text-green-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900">
            Email successfully verified!
          </h3>
          <p className="mb-6 text-sm text-gray-600">
            Your email address has been confirmed with Appwrite. You can now access your HomeVault.
          </p>
          <button
            onClick={() => navigate(user ? "/dashboard" : "/login")}
            className="inline-block rounded-lg bg-gold px-6 py-3 font-bold text-navy transition-colors hover:bg-yellow-400"
          >
            {user ? "Go to Vault Dashboard" : "Sign In to HomeVault"}
          </button>
        </div>
      </AuthCard>
    );
  }

  // ──────────────────────────────────────────────
  // State 3: Token verification failed
  // ──────────────────────────────────────────────
  if (hasToken && error) {
    return (
      <AuthCard title="Verification Failed" subtitle="Could not confirm your address">
        <div className="text-center">
          <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-red-100">
            <svg
              className="h-8 w-8 text-red-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"
              />
            </svg>
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900">
            Verification link invalid or expired
          </h3>
          <p className="mb-6 text-sm text-red-600">{error}</p>
          <div className="space-y-3">
            <Link
              to="/login"
              className="inline-block rounded-lg bg-gold px-6 py-3 font-bold text-navy transition-colors hover:bg-yellow-400"
            >
              Back to Sign In
            </Link>
          </div>
        </div>
      </AuthCard>
    );
  }

  // ──────────────────────────────────────────────
  // State 4: Post-registration or Unverified warning
  // ──────────────────────────────────────────────
  return (
    <AuthCard
      title="Verify Your Email"
      subtitle={redirectedBecauseUnverified ? "Account verification required" : "One more step before accessing your vault"}
    >
      {!isConfigured && (
        <div className="mb-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
          <strong>Setup required:</strong> Appwrite authentication is not configured.
          Email verification requires valid <code className="font-mono text-xs">VITE_APPWRITE_ENDPOINT</code> and{" "}
          <code className="font-mono text-xs">VITE_APPWRITE_PROJECT_ID</code>.
        </div>
      )}

      <div className="text-center">
        <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-blue-100">
          <svg
            className="h-8 w-8 text-blue-600"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
            />
          </svg>
        </div>

        <h3 className="mb-2 text-lg font-semibold text-gray-900">
          {redirectedBecauseUnverified ? "Email verification required" : "Check your inbox"}
        </h3>

        {verificationSent ? (
          <p className="mb-4 text-sm text-gray-600">
            {registeredEmail ? (
              <>
                A verification link has been sent to{" "}
                <strong className="text-gray-900">{registeredEmail}</strong>.
              </>
            ) : (
              "A verification link has been sent to your registered email address."
            )}
          </p>
        ) : (
          <div className="mb-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800 text-left">
            <strong>Notice:</strong> Your account was registered in Appwrite, but the verification email could not be sent automatically.
            {emailError && <div className="mt-1 text-xs text-amber-700 font-mono">{emailError}</div>}
            <div className="mt-2 text-xs text-amber-700">
              Please ensure SMTP/Email delivery is configured in your Appwrite Console under Settings &gt; Mail.
            </div>
          </div>
        )}

        <p className="mb-6 text-sm text-gray-500">
          You must verify your email address before you can access the private family document vault.
          Please click the link in your email to confirm your account.
        </p>

        {resendStatus && (
          <div className="mb-4 rounded-lg border border-blue-200 bg-blue-50 p-3 text-sm text-blue-800">
            {resendStatus}
          </div>
        )}

        <div className="space-y-3">
          {user && (
            <button
              onClick={handleResend}
              disabled={resending}
              className="w-full rounded-lg border border-gold bg-gold/10 px-4 py-2.5 text-sm font-semibold text-navy transition-colors hover:bg-gold/20 disabled:opacity-50"
            >
              {resending ? "Sending verification email…" : "Resend Verification Email"}
            </button>
          )}

          <Link
            to="/login"
            className="inline-block w-full rounded-lg bg-gold px-6 py-3 font-bold text-navy transition-colors hover:bg-yellow-400"
          >
            Go to Sign In
          </Link>

          <p className="text-sm text-gray-500">
            Wrong email address?{" "}
            <Link
              to="/register"
              className="font-medium text-navy hover:text-gold hover:underline"
            >
              Register with a different email
            </Link>
          </p>
        </div>
      </div>
    </AuthCard>
  );
};

export default VerifyEmailPage;
