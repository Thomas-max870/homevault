// src/components/auth/ResetPasswordPage.tsx
// Password reset page connected to Appwrite updateRecovery API.
// Reads userId and secret from URL query params.

import React, { useState } from "react";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { AuthNotConfiguredError } from "../../authBackend";
import AuthCard from "./AuthCard";
import PasswordInput from "./PasswordInput";

const ResetPasswordPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { completePasswordRecovery, isConfigured } = useAuth();

  const userId = searchParams.get("userId") || "";
  const secret = searchParams.get("secret") || "";

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  // Check for missing token parameters.
  const hasToken = Boolean(userId && secret);

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!password) {
      newErrors.password = "New password is required.";
    } else if (password.length < 8) {
      newErrors.password = "Password must be at least 8 characters.";
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = "Please confirm your new password.";
    } else if (password !== confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    setErrors({});

    if (!validate()) return;

    setSubmitting(true);

    try {
      await completePasswordRecovery(userId, secret, password, confirmPassword);
      setSuccess(true);
    } catch (err) {
      if (err instanceof AuthNotConfiguredError) {
        setErrors({ form: err.message });
      } else if (err instanceof Error) {
        setErrors({
          form:
            err.message ||
            "Password reset failed. The link may be expired or invalid.",
        });
      } else {
        setErrors({
          form: "Password reset failed. The link may be expired or invalid.",
        });
      }
    } finally {
      setSubmitting(false);
    }
  };

  // Missing or invalid recovery link.
  if (!hasToken) {
    return (
      <AuthCard title="Invalid Reset Link" subtitle="Token information missing">
        <div className="text-center">
          <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-red-100">
            <svg
              className="h-8 w-8 text-red-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"
              />
            </svg>
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900">
            Missing recovery token
          </h3>
          <p className="mb-6 text-sm text-gray-600">
            This password reset link is invalid or incomplete. Please request a
            new password reset link from the sign-in page.
          </p>
          <Link
            to="/forgot-password"
            className="inline-block rounded-lg bg-gold px-6 py-3 font-bold text-navy transition-colors hover:bg-yellow-400"
          >
            Request a new reset link
          </Link>
        </div>
      </AuthCard>
    );
  }

  // Successful reset.
  if (success) {
    return (
      <AuthCard title="Password Reset" subtitle="Your password has been updated">
        <div className="text-center">
          <div className="mb-4 inline-flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
            <svg
              className="h-8 w-8 text-green-600"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
          <h3 className="mb-2 text-lg font-semibold text-gray-900">
            Password updated successfully
          </h3>
          <p className="mb-6 text-sm text-gray-600">
            Your password has been updated in Appwrite. You can now sign in with your new
            password.
          </p>
          <button
            onClick={() => navigate("/login")}
            className="rounded-lg bg-gold px-6 py-3 font-bold text-navy transition-colors hover:bg-yellow-400"
          >
            Sign In
          </button>
        </div>
      </AuthCard>
    );
  }

  return (
    <AuthCard
      title="Reset Password"
      subtitle="Enter your new password below"
    >
      {!isConfigured && (
        <div className="mb-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
          <strong>Setup required:</strong> Appwrite authentication is not configured.
          Password reset requires valid <code className="font-mono text-xs">VITE_APPWRITE_ENDPOINT</code> and{" "}
          <code className="font-mono text-xs">VITE_APPWRITE_PROJECT_ID</code>.
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        {errors.form && (
          <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-700">
            {errors.form}
          </div>
        )}

        <PasswordInput
          id="reset-password"
          name="password"
          label="New password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Minimum 8 characters"
          error={errors.password}
          required
          autoComplete="new-password"
          disabled={submitting}
        />

        <PasswordInput
          id="reset-confirm-password"
          name="confirmPassword"
          label="Confirm new password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          placeholder="Re-enter your new password"
          error={errors.confirmPassword}
          required
          autoComplete="new-password"
          disabled={submitting}
        />

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-lg bg-gold px-4 py-3 font-bold text-navy transition-colors hover:bg-yellow-400 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-navy/30 border-t-navy" />
              Resetting password…
            </span>
          ) : (
            "Reset Password"
          )}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-gray-500">
        <Link
          to="/login"
          className="font-medium text-navy hover:text-gold hover:underline"
        >
          ← Back to Sign In
        </Link>
      </p>
    </AuthCard>
  );
};

export default ResetPasswordPage;
