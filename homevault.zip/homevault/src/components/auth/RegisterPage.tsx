// src/components/auth/RegisterPage.tsx
// HomeVault registration page connected to Appwrite.

import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { AuthNotConfiguredError } from "../../authBackend";
import AuthCard from "./AuthCard";
import PasswordInput from "./PasswordInput";

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { register, isConfigured } = useAuth();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!name.trim()) {
      newErrors.name = "Full name is required.";
    }

    if (!email.trim()) {
      newErrors.email = "Email address is required.";
    } else if (!emailRegex.test(email.trim())) {
      newErrors.email = "Please enter a valid email address.";
    }

    if (!password) {
      newErrors.password = "Password is required.";
    } else if (password.length < 8) {
      newErrors.password = "Password must be at least 8 characters.";
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = "Please confirm your password.";
    } else if (password !== confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
    }

    if (!acceptedPrivacy) {
      newErrors.privacy = "You must accept the privacy notice to create an account.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    setErrors({});

    if (!validate()) return;

    setSubmitting(true);

    try {
      const result = await register(name.trim(), email.trim(), password);
      // Registration succeeded — navigate to verify-email without granting vault access
      navigate("/verify-email", {
        state: {
          email: email.trim(),
          verificationSent: result.verificationSent,
          emailError: result.message,
        },
      });
    } catch (err) {
      if (err instanceof AuthNotConfiguredError) {
        setErrors({ form: err.message });
      } else if (err instanceof Error) {
        setErrors({
          form: err.message || "Registration failed. Please try again.",
        });
      } else {
        setErrors({ form: "Registration failed. Please try again." });
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthCard title="Create Account" subtitle="Set up your family document vault">
      {/* Provider not configured notice */}
      {!isConfigured && (
        <div className="mb-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
          <strong>Setup required:</strong> Appwrite authentication is not configured.
          Please set <code className="rounded bg-amber-100 px-1 font-mono text-xs">VITE_APPWRITE_ENDPOINT</code> and{" "}
          <code className="rounded bg-amber-100 px-1 font-mono text-xs">VITE_APPWRITE_PROJECT_ID</code> in your{" "}
          <code className="font-mono text-xs">.env</code> file.
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        {/* Form-level error */}
        {errors.form && (
          <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-700">
            {errors.form}
          </div>
        )}

        {/* Full name */}
        <div>
          <label
            htmlFor="register-name"
            className="mb-1 block text-sm font-medium text-gray-700"
          >
            Full name <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="register-name"
            name="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="John Doe"
            required
            autoComplete="name"
            disabled={submitting}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? "register-name-error" : undefined}
            className={`w-full rounded-lg border px-4 py-3 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-gold ${
              errors.name ? "border-red-400" : "border-gray-300"
            }`}
          />
          {errors.name && (
            <p id="register-name-error" className="mt-1 text-sm text-red-500">
              {errors.name}
            </p>
          )}
        </div>

        {/* Email */}
        <div>
          <label
            htmlFor="register-email"
            className="mb-1 block text-sm font-medium text-gray-700"
          >
            Email address <span className="text-red-500">*</span>
          </label>
          <input
            type="email"
            id="register-email"
            name="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
            autoComplete="email"
            disabled={submitting}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "register-email-error" : undefined}
            className={`w-full rounded-lg border px-4 py-3 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-gold ${
              errors.email ? "border-red-400" : "border-gray-300"
            }`}
          />
          {errors.email && (
            <p id="register-email-error" className="mt-1 text-sm text-red-500">
              {errors.email}
            </p>
          )}
        </div>

        {/* Password */}
        <div>
          <PasswordInput
            id="register-password"
            name="password"
            label="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Minimum 8 characters"
            error={errors.password}
            required
            autoComplete="new-password"
            disabled={submitting}
          />
          <p className="mt-1 text-xs text-gray-500">
            Minimum 8 characters. Long passphrases are encouraged.
          </p>
        </div>

        {/* Confirm password */}
        <PasswordInput
          id="register-confirm-password"
          name="confirmPassword"
          label="Confirm password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          placeholder="Re-enter your password"
          error={errors.confirmPassword}
          required
          autoComplete="new-password"
          disabled={submitting}
        />

        {/* Privacy notice */}
        <div>
          <label className="flex items-start gap-2 text-sm text-gray-600">
            <input
              type="checkbox"
              checked={acceptedPrivacy}
              onChange={(e) => setAcceptedPrivacy(e.target.checked)}
              disabled={submitting}
              className="mt-0.5 h-4 w-4 rounded border-gray-300 text-gold focus:ring-gold"
              aria-invalid={Boolean(errors.privacy)}
            />
            <span>
              I accept the{" "}
              <span className="font-medium text-navy">privacy notice</span> and
              understand that my documents will be stored securely.
            </span>
          </label>
          {errors.privacy && (
            <p className="mt-1 text-sm text-red-500">{errors.privacy}</p>
          )}
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-lg bg-gold px-4 py-3 font-bold text-navy transition-colors hover:bg-yellow-400 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {submitting ? (
            <span className="flex items-center justify-center gap-2">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-navy/30 border-t-navy" />
              Creating account…
            </span>
          ) : (
            "Create Account"
          )}
        </button>
      </form>

      {/* Sign-in link */}
      <p className="mt-6 text-center text-sm text-gray-500">
        Already have an account?{" "}
        <Link
          to="/login"
          className="font-medium text-navy hover:text-gold hover:underline"
        >
          Sign In
        </Link>
      </p>
    </AuthCard>
  );
};

export default RegisterPage;
