// src/components/auth/ChangePasswordPage.tsx
// Allows authenticated users to change their password via Appwrite updatePassword API.

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { AuthNotConfiguredError } from "../../authBackend";
import NavBar from "../NavBar";
import PasswordInput from "./PasswordInput";

const ChangePasswordPage: React.FC = () => {
  const { changePassword, isConfigured } = useAuth();

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!currentPassword) {
      newErrors.currentPassword = "Current password is required.";
    }

    if (!newPassword) {
      newErrors.newPassword = "New password is required.";
    } else if (newPassword.length < 8) {
      newErrors.newPassword = "Password must be at least 8 characters.";
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = "Please confirm your new password.";
    } else if (newPassword !== confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
    }

    if (currentPassword && newPassword && currentPassword === newPassword) {
      newErrors.newPassword =
        "New password must be different from the current password.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    setErrors({});
    setSuccess(false);

    if (!validate()) return;

    setSubmitting(true);

    try {
      await changePassword(currentPassword, newPassword);
      setSuccess(true);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      if (err instanceof AuthNotConfiguredError) {
        setErrors({ form: err.message });
      } else if (err instanceof Error) {
        setErrors({
          form: err.message || "Failed to change password. Please try again.",
        });
      } else {
        setErrors({ form: "Failed to change password. Please try again." });
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <NavBar />
      <div className="container py-8">
        <div className="mx-auto max-w-lg">
          <div className="mb-6">
            <Link
              to="/settings"
              className="text-sm text-gold hover:underline"
            >
              ← Back to Settings
            </Link>
          </div>

          <div className="rounded-2xl bg-white p-8 shadow-xl">
            <h2 className="mb-1 text-center text-2xl font-bold text-gray-900">
              Change Password
            </h2>
            <p className="mb-6 text-center text-sm text-gray-500">
              Update your account password
            </p>

            {/* Provider not configured notice */}
            {!isConfigured && (
              <div className="mb-4 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
                <strong>Setup required:</strong> Appwrite authentication is not configured.
                Password changes require valid <code className="font-mono text-xs">VITE_APPWRITE_ENDPOINT</code> and{" "}
                <code className="font-mono text-xs">VITE_APPWRITE_PROJECT_ID</code>.
              </div>
            )}

            {/* Success message */}
            {success && (
              <div className="mb-4 rounded-lg border border-green-300 bg-green-50 p-3 text-sm text-green-700">
                Your password has been updated successfully.
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              {/* Form-level error */}
              {errors.form && (
                <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-700">
                  {errors.form}
                </div>
              )}

              {/* Current password */}
              <PasswordInput
                id="change-current-password"
                name="currentPassword"
                label="Current password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Enter your current password"
                error={errors.currentPassword}
                required
                autoComplete="current-password"
                disabled={submitting}
              />

              <hr className="my-2 border-gray-200" />

              {/* New password */}
              <div>
                <PasswordInput
                  id="change-new-password"
                  name="newPassword"
                  label="New password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Minimum 8 characters"
                  error={errors.newPassword}
                  required
                  autoComplete="new-password"
                  disabled={submitting}
                />
                <p className="mt-1 text-xs text-gray-500">
                  Minimum 8 characters. Long passphrases are encouraged.
                </p>
              </div>

              {/* Confirm new password */}
              <PasswordInput
                id="change-confirm-password"
                name="confirmPassword"
                label="Confirm new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter your new password"
                error={errors.confirmPassword}
                required
                autoComplete="new-password"
                disabled={submitting}
              />

              {/* Submit */}
              <button
                type="submit"
                disabled={submitting}
                className="w-full rounded-lg bg-gold px-4 py-3 font-bold text-navy transition-colors hover:bg-yellow-400 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {submitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-navy/30 border-t-navy" />
                    Updating password…
                  </span>
                ) : (
                  "Update Password"
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChangePasswordPage;
