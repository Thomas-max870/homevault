// src/components/LoadingScreen.tsx
// Full-screen loading indicator shown while checking auth session.

import React from "react";

const LoadingScreen: React.FC = () => {
  return (
    <div className="flex min-h-screen items-center justify-center bg-navy">
      <div className="text-center">
        {/* Gold animated spinner */}
        <div className="mx-auto mb-4 h-12 w-12 animate-spin rounded-full border-4 border-gold/30 border-t-gold" />
        <p className="text-lg font-medium text-white">Loading HomeVault…</p>
      </div>
    </div>
  );
};

export default LoadingScreen;
