// src/components/UploadDocument.tsx

import React, { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { api, ALLOWED_FILE_TYPES, MAX_FILE_SIZE_BYTES } from "../api";
import { useAuth } from "../contexts/AuthContext";
import NavBar from "./NavBar";

type DocumentPermission = "private" | "family";

interface FormState {
  title: string;
  category: string;
  relatedPerson: string;
  date: string;
  expiryDate: string;
  notes: string;
  file: File | null;
  permission: DocumentPermission;
}

const initialState: FormState = {
  title: "",
  category: "",
  relatedPerson: "",
  date: "",
  expiryDate: "",
  notes: "",
  file: null,
  permission: "private",
};

const UploadDocument: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  const locationState = location.state as
    | { preselectedCategory?: string }
    | null;

  const preselectedSlug = locationState?.preselectedCategory ?? "";

  const [form, setForm] = useState<FormState>(initialState);
  const [categories, setCategories] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [loadingCategories, setLoadingCategories] = useState(true);

  const slugify = (value: string): string =>
    value
      .toLowerCase()
      .trim()
      .replace(/\s+/g, "-")
      .replace(/[^a-z0-9-]/g, "");

  // Load categories.
  useEffect(() => {
    let cancelled = false;

    const loadCategories = async () => {
      try {
        const result = await api.getCategories();

        if (cancelled) return;

        const safeCategories = Array.isArray(result) ? result : [];

        setCategories(safeCategories);

        if (preselectedSlug) {
          const selected = safeCategories.find(
            (category) => slugify(category) === preselectedSlug
          );

          if (selected) {
            setForm((previous) => ({
              ...previous,
              category: selected,
            }));
          }
        }
      } catch (error) {
        console.error("Could not load document categories:", error);

        if (!cancelled) {
          setErrors((previous) => ({
            ...previous,
            categories: "Could not load categories. Please refresh the page.",
          }));
        }
      } finally {
        if (!cancelled) {
          setLoadingCategories(false);
        }
      }
    };

    void loadCategories();

    return () => {
      cancelled = true;
    };
  }, [preselectedSlug]);

  const handleChange = (
    event: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    const { name, value } = event.target;

    setForm((previous) => ({
      ...previous,
      [name]: value,
    }));

    setErrors((previous) => {
      const next = { ...previous };
      delete next[name];
      delete next.submit;
      return next;
    });
  };

  const handleFileChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const selectedFile = event.target.files?.[0] ?? null;

    if (!selectedFile) {
      setForm((previous) => ({ ...previous, file: null }));
      return;
    }

    if (!ALLOWED_FILE_TYPES.includes(selectedFile.type)) {
      setErrors((previous) => ({
        ...previous,
        file: "Unsupported file type. Select a PDF, JPEG, PNG, or WebP file.",
      }));

      setForm((previous) => ({ ...previous, file: null }));
      event.target.value = "";
      return;
    }

    if (selectedFile.size > MAX_FILE_SIZE_BYTES) {
      setErrors((previous) => ({
        ...previous,
        file: "The selected file exceeds the 25 MB limit.",
      }));

      setForm((previous) => ({ ...previous, file: null }));
      event.target.value = "";
      return;
    }

    setForm((previous) => ({
      ...previous,
      file: selectedFile,
    }));

    setErrors((previous) => {
      const next = { ...previous };
      delete next.file;
      delete next.submit;
      return next;
    });
  };

  const validate = (): boolean => {
    const nextErrors: Record<string, string> = {};

    if (!form.title.trim()) {
      nextErrors.title = "Document title is required.";
    }

    if (!form.category) {
      nextErrors.category = "Please select a category.";
    }

    if (!form.file) {
      nextErrors.file = "Please select a document to upload.";
    } else {
      if (!ALLOWED_FILE_TYPES.includes(form.file.type)) {
        nextErrors.file = "Please select a supported PDF or image file.";
      } else if (form.file.size > MAX_FILE_SIZE_BYTES) {
        nextErrors.file = "The file exceeds the 25 MB limit.";
      }
    }

    if (!user) {
      nextErrors.submit = "Please sign in before uploading a document.";
    }

    setErrors(nextErrors);

    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = async (
    event: React.FormEvent<HTMLFormElement>
  ) => {
    event.preventDefault();

    if (uploading || !validate() || !form.file || !user) {
      return;
    }

    setUploading(true);
    setSuccess(false);

    setErrors((previous) => {
      const next = { ...previous };
      delete next.submit;
      return next;
    });

    const documentMetadata = {
      title: form.title.trim(),
      category: form.category,
      relatedPerson: form.relatedPerson.trim() || undefined,
      date: form.date || undefined,
      expiryDate: form.expiryDate || undefined,
      notes: form.notes.trim() || undefined,
      fileName: form.file.name,
      permission: form.permission,
    };

    try {
      await api.addDocument(
        documentMetadata,
        form.file,
        {
          id: user.id,
          email: user.email,
        }
      );

      setSuccess(true);
      setForm(initialState);

      window.setTimeout(() => {
        navigate("/dashboard");
      }, 1200);
    } catch (error: unknown) {
      console.error("HomeVault document upload failed:", error);

      const message =
        error instanceof Error
          ? error.message
          : "An unexpected error occurred while uploading the document.";

      setErrors((previous) => ({
        ...previous,
        submit: message,
      }));
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <NavBar />

      <main className="container mx-auto max-w-2xl px-4 py-8">
        <h2 className="mb-6 text-2xl font-semibold text-navy">
          Upload Document
        </h2>

        <form
          onSubmit={handleSubmit}
          className="space-y-5 rounded-lg bg-white p-6 shadow"
          noValidate
        >
          {/* Document title */}
          <div>
            <label
              htmlFor="title"
              className="mb-1 block font-medium"
            >
              Document Title <span className="text-red-600">*</span>
            </label>

            <input
              id="title"
              name="title"
              type="text"
              value={form.title}
              onChange={handleChange}
              disabled={uploading}
              className="w-full rounded border border-gray-300 px-3 py-2"
              aria-invalid={Boolean(errors.title)}
            />

            {errors.title && (
              <p className="mt-1 text-sm text-red-600">
                {errors.title}
              </p>
            )}
          </div>

          {/* Category */}
          <div>
            <label
              htmlFor="category"
              className="mb-1 block font-medium"
            >
              Category <span className="text-red-600">*</span>
            </label>

            <select
              id="category"
              name="category"
              value={form.category}
              onChange={handleChange}
              disabled={uploading || loadingCategories}
              className="w-full rounded border border-gray-300 bg-white px-3 py-2"
              aria-invalid={Boolean(errors.category)}
            >
              <option value="">
                {loadingCategories
                  ? "Loading categories..."
                  : "Select a category"}
              </option>

              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>

            {errors.category && (
              <p className="mt-1 text-sm text-red-600">
                {errors.category}
              </p>
            )}

            {errors.categories && (
              <p className="mt-1 text-sm text-red-600">
                {errors.categories}
              </p>
            )}
          </div>

          {/* Related person */}
          <div>
            <label
              htmlFor="relatedPerson"
              className="mb-1 block font-medium"
            >
              Related Person (optional)
            </label>

            <input
              id="relatedPerson"
              name="relatedPerson"
              type="text"
              value={form.relatedPerson}
              onChange={handleChange}
              disabled={uploading}
              className="w-full rounded border border-gray-300 px-3 py-2"
            />
          </div>

          {/* Document date */}
          <div>
            <label
              htmlFor="date"
              className="mb-1 block font-medium"
            >
              Document Date (optional)
            </label>

            <input
              id="date"
              name="date"
              type="date"
              value={form.date}
              onChange={handleChange}
              disabled={uploading}
              className="w-full rounded border border-gray-300 px-3 py-2"
            />
          </div>

          {/* Expiry date */}
          <div>
            <label
              htmlFor="expiryDate"
              className="mb-1 block font-medium"
            >
              Expiry Date (optional)
            </label>

            <input
              id="expiryDate"
              name="expiryDate"
              type="date"
              value={form.expiryDate}
              onChange={handleChange}
              disabled={uploading}
              className="w-full rounded border border-gray-300 px-3 py-2"
            />
          </div>

          {/* Notes */}
          <div>
            <label
              htmlFor="notes"
              className="mb-1 block font-medium"
            >
              Notes (optional)
            </label>

            <textarea
              id="notes"
              name="notes"
              rows={3}
              value={form.notes}
              onChange={handleChange}
              disabled={uploading}
              className="w-full rounded border border-gray-300 px-3 py-2"
            />
          </div>

          {/* File */}
          <div>
            <label
              htmlFor="file"
              className="mb-1 block font-medium"
            >
              Document File <span className="text-red-600">*</span>
            </label>

            <input
              id="file"
              name="file"
              type="file"
              accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
              onChange={handleFileChange}
              disabled={uploading}
              className="w-full rounded border border-gray-300 px-3 py-2"
              aria-invalid={Boolean(errors.file)}
            />

            {form.file && (
              <p className="mt-1 text-sm text-gray-600">
                Selected: {form.file.name} (
                {(form.file.size / 1024).toFixed(1)} KB)
              </p>
            )}

            {errors.file && (
              <p className="mt-1 text-sm text-red-600">
                {errors.file}
              </p>
            )}

            <p className="mt-1 text-sm text-gray-500">
              PDF, JPEG, PNG, or WebP. Maximum size: 25 MB.
            </p>
          </div>

          {/* Access permission */}
          <div>
            <label
              htmlFor="permission"
              className="mb-1 block font-medium"
            >
              Access Permissions
            </label>

            <select
              id="permission"
              name="permission"
              value={form.permission}
              onChange={handleChange}
              disabled={uploading}
              className="w-full rounded border border-gray-300 bg-white px-3 py-2"
            >
              <option value="private">
                Private — Only You
              </option>

              <option value="family">
                Family Members
              </option>
            </select>

            <p className="mt-1 text-sm text-gray-500">
              Family access must be configured and enforced by
              Appwrite permissions. Selecting Family alone does not
              grant access to other users.
            </p>
          </div>

          {/* Submit and cancel */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="submit"
              disabled={uploading || loadingCategories}
              className="rounded bg-navy px-4 py-2 text-white transition-colors hover:bg-gold disabled:cursor-not-allowed disabled:opacity-50"
            >
              {uploading ? "Uploading..." : "Upload Document"}
            </button>

            <button
              type="button"
              disabled={uploading}
              onClick={() => navigate("/dashboard")}
              className="rounded border border-navy px-4 py-2 text-navy hover:bg-gray-100 disabled:opacity-50"
            >
              Cancel
            </button>
          </div>

          {errors.submit && (
            <div
              role="alert"
              className="rounded border border-red-200 bg-red-50 p-3 text-sm text-red-700"
            >
              {errors.submit}
            </div>
          )}

          {success && (
            <p className="rounded bg-green-50 p-3 text-sm text-green-700">
              Document uploaded successfully. Redirecting...
            </p>
          )}
        </form>
      </main>
    </div>
  );
};

export default UploadDocument;