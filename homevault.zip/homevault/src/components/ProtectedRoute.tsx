// src/components/ProtectedRoute.tsx
// Wraps routes that require authentication.
// Shows LoadingScreen during session check, redirects to /login if unauthenticated,
// and enforces email verification before granting access to vault routes.

import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import LoadingScreen from "./LoadingScreen";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  // Show loading screen while checking session — never flash protected content.
  if (loading) {
    return <LoadingScreen />;
  }

  // Not authenticated — redirect to login, preserving intended destination.
  if (!user) {
    return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  }

  // Authenticated but email not yet verified — enforce verification before vault access
  if (!user.emailVerified) {
    return (
      <Navigate
        to="/verify-email"
        state={{ email: user.email, unverified: true }}
        replace
      />
    );
  }

  return <>{children}</>;
};

export default ProtectedRoute;
