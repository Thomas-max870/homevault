// src/components/CategoryPage.tsx
import React, { useEffect, useState } from "react";
import { useParams, Link, useLocation, useNavigate } from "react-router-dom";
import { api, DocumentItem } from "../api";
import { useAuth } from "../contexts/AuthContext";
import NavBar from "./NavBar";

// Helper to slugify category names (same as in CategoriesPage)
const slugify = (text: string) =>
  text.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9\-]/g, "");

// Map slug back to display name – we keep a simple reverse lookup.
const reverseSlug = (slug: string, categories: string[]) => {
  const found = categories.find((c) => slugify(c) === slug);
  return found || "Unknown Category";
};

// Human‑readable size
const formatSize = (bytes?: number) => {
  if (bytes === undefined) return "-";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  return `${mb.toFixed(1)} MB`;
};

const CategoryPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [categories, setCategories] = useState<string[]>([]);
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [search, setSearch] = useState<string>("");

  useEffect(() => {
    const fetch = async () => {
      const cats = await api.getCategories();
      setCategories(cats);
      const docs = await api.getDocuments(user?.id);
      setDocuments(docs);
    };
    fetch();
  }, [user?.id]);


  const displayName = slug ? reverseSlug(slug, categories) : "";

  const filtered = documents.filter(
    (doc) => slugify(doc.category) === slug && doc.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <NavBar />
      <div className="container py-8 max-w-4xl">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-semibold text-navy">{displayName}</h2>
          <Link
            to="/upload"
            state={{ preselectedCategory: slug }}
            className="px-4 py-2 bg-navy text-white rounded hover:bg-gold"
          >
            Upload Document
          </Link>
        </div>
        <p className="text-gray-600 mb-4">{/* placeholder description */}Documents in the {displayName} category.</p>
        <input
          type="text"
          placeholder="Search by title…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full mb-4 border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-navy border-gray-300"
        />
        {filtered.length === 0 ? (
          <p className="text-gray-600">No documents in this category.</p>
        ) : (
          <ul className="space-y-3">
            {filtered.map((doc) => (
              <li
                key={doc.id}
                className="bg-white rounded p-4 shadow flex flex-col md:flex-row md:items-center md:justify-between"
              >
                <div>
                  <p className="font-medium text-navy">{doc.title}</p>
                  <p className="text-sm text-gray-600">
                    {doc.fileName} — {doc.fileSize ? formatSize(doc.fileSize) : "-"}
                    {doc.date && ` | Date: ${doc.date}`}
                    {doc.expiryDate && ` | Expires: ${doc.expiryDate}`}
                  </p>
                </div>
                <Link
                  to={`/documents/${doc.id}`}
                  className="mt-2 md:mt-0 text-sm text-navy hover:underline"
                >
                  View Details
                </Link>
              </li>
            ))}
          </ul>
        )}
        <div className="mt-6">
          <Link to="/categories" className="text-gold underline hover:text-navy">
            ← Back to All Categories
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CategoryPage;
