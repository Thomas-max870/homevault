// src/components/CategoryList.tsx
import React, { useEffect, useState } from "react";
import { api } from "../api";
import NavBar from "./NavBar";

const CategoryList: React.FC = () => {
  const [categories, setCategories] = useState<string[]>([]);

  useEffect(() => {
    const fetch = async () => {
      const cats = await api.getCategories();
      setCategories(cats);
    };
    fetch();
  }, []);

  return (
    <div>
      <NavBar />
      <div className="container py-8">
        <h2 className="text-2xl font-semibold mb-4 text-navy">Document Categories</h2>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {categories.map((cat) => (
            <li
              key={cat}
              className="bg-white rounded p-3 shadow hover:bg-gray-50 cursor-pointer"
            >
              {cat}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default CategoryList;
