// src/components/FamilySettings.tsx

import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import NavBar from "./NavBar";
import { api } from "../api";
import { useAuth } from "../contexts/AuthContext";

const FamilySettings: React.FC = () => {
  const { user } = useAuth();

  const [vaultName, setVaultName] = useState("");
  const [storageUsed, setStorageUsed] = useState(0);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function loadSettings() {
      setLoading(true);
      setError("");

      try {
        const [settings, usage] = await Promise.all([
          api.getSettings(user?.id),
          api.getStorageUsage(user?.id),
        ]);

        if (cancelled) return;

        setVaultName(settings?.vaultName || "My Family Vault");
        setStorageUsed(usage?.used ?? 0);
      } catch (err: unknown) {
        if (cancelled) return;

        console.error("Failed to load vault settings:", err);

        setError(
          err instanceof Error
            ? err.message
            : "Could not load vault settings."
        );
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadSettings();

    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  function formatSize(bytes: number): string {
    if (bytes < 1024) {
      return `${bytes} B`;
    }

    if (bytes < 1024 * 1024) {
      return `${(bytes / 1024).toFixed(1)} KB`;
    }

    if (bytes < 1024 * 1024 * 1024) {
      return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    }

    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  }

  async function handleSaveVaultName(
    event: React.FormEvent<HTMLFormElement>
  ) {
    event.preventDefault();

    setError("");
    setSuccess("");

    const cleanedName = vaultName.trim();

    if (!cleanedName) {
      setError("Please enter a vault name.");
      return;
    }

    if (!user) {
      setError("Please sign in before saving settings.");
      return;
    }

    setSaving(true);

    try {
      await api.saveSettings(cleanedName, [], user.id);

      setVaultName(cleanedName);
      setSuccess("Vault name saved successfully.");
    } catch (err: unknown) {
      console.error("Failed to save vault name:", err);

      setError(
        err instanceof Error
          ? err.message
          : "Could not save the vault name."
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen bg-navy text-white">
      <NavBar />

      <main className="container mx-auto max-w-5xl px-4 py-8">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-yellow-300">
            Family & Vault Settings
          </h1>

          <p className="mt-2 text-sm text-slate-300">
            Manage your vault name, storage information, and account security.
          </p>
        </header>

        {error && (
          <div
            role="alert"
            className="mb-5 rounded-lg border border-red-500/40 bg-red-950/50 p-4 text-sm text-red-200"
          >
            {error}
          </div>
        )}

        {success && (
          <div
            role="status"
            className="mb-5 rounded-lg border border-green-500/40 bg-green-950/50 p-4 text-sm text-green-200"
          >
            {success}
          </div>
        )}

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {/* Vault configuration */}
          <section className="rounded-xl border border-slate-700 bg-slate-800 p-6 shadow-lg">
            <h2 className="mb-5 text-xl font-bold text-yellow-300">
              Vault Configuration
            </h2>

            <form
              onSubmit={handleSaveVaultName}
              className="space-y-5"
            >
              <div>
                <label
                  htmlFor="vaultName"
                  className="mb-2 block text-sm font-semibold"
                >
                  Vault Name
                </label>

                <input
                  id="vaultName"
                  type="text"
                  value={vaultName}
                  onChange={(event) => {
                    setVaultName(event.target.value);
                    setError("");
                    setSuccess("");
                  }}
                  disabled={loading || saving}
                  placeholder="My Family Vault"
                  className="w-full rounded-lg border border-slate-600 bg-slate-900 px-4 py-3 text-white outline-none focus:border-yellow-400 disabled:opacity-50"
                />
              </div>

              <div>
                <label
                  htmlFor="storageUsed"
                  className="mb-2 block text-sm font-semibold"
                >
                  Current Storage Used
                </label>

                <input
                  id="storageUsed"
                  type="text"
                  readOnly
                  value={
                    loading
                      ? "Calculating..."
                      : `${formatSize(storageUsed)} cloud storage`
                  }
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-3 text-slate-300"
                />
              </div>

              <button
                type="submit"
                disabled={loading || saving || !user}
                className="rounded-lg bg-yellow-400 px-5 py-3 font-bold text-slate-900 transition hover:bg-yellow-300 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {saving ? "Saving..." : "Save Vault Name"}
              </button>
            </form>
          </section>

          {/* Account security */}
          <section className="rounded-xl border border-slate-700 bg-slate-800 p-6 shadow-lg">
            <h2 className="mb-3 text-xl font-bold text-yellow-300">
              Account Security
            </h2>

            <p className="mb-5 text-sm text-slate-300">
              Change your HomeVault account password securely.
            </p>

            <Link
              to="/change-password"
              className="inline-block rounded-lg bg-slate-700 px-4 py-3 font-semibold text-white transition hover:bg-slate-600"
            >
              Change Account Password →
            </Link>
          </section>

          {/* Family sharing status */}
          <section className="rounded-xl border border-amber-500/40 bg-slate-800 p-6 shadow-lg md:col-span-2">
            <h2 className="mb-3 text-xl font-bold text-yellow-300">
              Family Team Sharing
            </h2>

            <p className="mb-4 text-sm leading-6 text-slate-300">
              Family invitations are temporarily unavailable because
              the Appwrite Team has not yet been configured correctly.
              The application was receiving a 404 response when it
              attempted to load family memberships.
            </p>

            <div className="rounded-lg border border-amber-500/30 bg-amber-950/30 p-4">
              <p className="font-semibold text-amber-200">
                Team configuration required
              </p>

              <p className="mt-2 text-sm text-amber-100/80">
                Create or select the correct Team in Appwrite Console,
                then configure the matching Team ID in your application.
                Family invitations can be enabled after that configuration
                is verified.
              </p>
            </div>

            <p className="mt-4 text-xs text-slate-400">
              Family sharing is not enabled by this page. Do not assume
              that selecting a family permission grants another account
              access to your documents.
            </p>
          </section>
        </div>
      </main>
    </div>
  );
};

export default FamilySettings;