// src/components/Dashboard.tsx
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, DocumentItem } from "../api";
import { useAuth } from "../contexts/AuthContext";
import NavBar from "./NavBar";

interface Stats {
  total: number;
  recent: number;
  shared: number;
  expiring: number;
  storageUsage: string;
}

const formatBytes = (bytes: number): string => {
  if (bytes === 0) return "0 B";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(2)} MB`;
  const gb = mb / 1024;
  return `${gb.toFixed(2)} GB`;
};

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<Stats>({
    total: 0,
    recent: 0,
    shared: 0,
    expiring: 0,
    storageUsage: "0 B",
  });
  const [recentDocs, setRecentDocs] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    const fetch = async () => {
      try {
        setLoading(true);
        const docs = await api.getDocuments(user?.id);
        const now = Date.now();

        const recent = docs.filter((d) => {
          const docDate = d.createdAt ? new Date(d.createdAt).getTime() : d.date ? new Date(d.date).getTime() : now;
          return now - docDate < 7 * 24 * 60 * 60 * 1000;
        }).length;

        const shared = docs.filter(
          (d) => d.permission === "family" || (d.sharedWith && d.sharedWith.length > 0)
        ).length;

        const expiring = docs.filter(
          (d) => d.expiryDate && new Date(d.expiryDate).getTime() - now > 0 && new Date(d.expiryDate).getTime() - now < 30 * 24 * 60 * 60 * 1000
        ).length;

        // Accurate sum of actual file sizes in bytes
        const totalBytes = docs.reduce((acc, d) => acc + (d.fileSize || 0), 0);
        const storageUsage = formatBytes(totalBytes);

        setStats({
          total: docs.length,
          recent,
          shared,
          expiring,
          storageUsage,
        });

        // Sort by creation or document date descending
        const sorted = [...docs].sort((a, b) => {
          const ad = a.createdAt ? new Date(a.createdAt).getTime() : a.date ? new Date(a.date).getTime() : 0;
          const bd = b.createdAt ? new Date(b.createdAt).getTime() : b.date ? new Date(b.date).getTime() : 0;
          return bd - ad;
        });
        setRecentDocs(sorted.slice(0, 5));
      } catch (err: any) {
        console.error("Dashboard error:", err);
        setError("Failed to load dashboard metrics.");
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [user?.id]);

  const Card: React.FC<{ title: string; value: string | number; color?: string }> = ({
    title,
    value,
    color = "text-white",
  }) => (
    <div className="bg-slate-800 border border-slate-700 rounded-xl shadow-md p-5 text-center transition-transform hover:-translate-y-0.5">
      <h3 className="text-yellow-300 text-xs font-semibold uppercase tracking-wider mb-2">
        {title}
      </h3>
      <p className={`text-3xl font-bold ${color}`}>{value}</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-navy text-white">
      <NavBar />
      <div className="container mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8 gap-4">
          <div>
            <h2 className="text-3xl font-bold text-yellow-300">Vault Dashboard</h2>
            <p className="text-slate-300 text-sm mt-1">
              Welcome back, {user?.name || user?.email || "Vault Owner"}.
            </p>
          </div>
          <Link
            to="/upload"
            className="inline-flex items-center justify-center bg-yellow-400 text-slate-900 font-bold px-5 py-2.5 rounded-lg shadow hover:bg-yellow-300 transition-colors"
          >
            + Upload New Document
          </Link>
        </div>

        {error && (
          <div className="bg-red-950 border border-red-800 text-red-300 p-4 rounded-xl mb-6">
            {error}
          </div>
        )}

        {loading ? (
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-8 text-center text-slate-300">
            Calculating vault statistics and storage usage...
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
              <Card title="Total Documents" value={stats.total} />
              <Card title="Recent (7d)" value={stats.recent} />
              <Card title="Family Shared" value={stats.shared} />
              <Card
                title="Expiring (30d)"
                value={stats.expiring}
                color={stats.expiring > 0 ? "text-amber-400" : "text-white"}
              />
              <Card title="Actual Storage" value={stats.storageUsage} />
            </div>

            {/* Recent Documents Section */}
            <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-6 shadow-lg mb-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-yellow-300">Recent Documents</h3>
                <Link
                  to="/documents"
                  className="text-sm text-yellow-300 hover:text-white underline transition-colors"
                >
                  View All Documents ({stats.total})
                </Link>
              </div>

              {recentDocs.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-300 mb-3">No documents in your vault yet.</p>
                  <Link
                    to="/upload"
                    className="text-yellow-300 hover:underline text-sm font-semibold"
                  >
                    Upload your first document
                  </Link>
                </div>
              ) : (
                <ul className="divide-y divide-slate-700">
                  {recentDocs.map((doc) => (
                    <li
                      key={doc.id}
                      className="py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 hover:bg-slate-700/30 px-3 rounded-lg transition-colors"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-white">{doc.title}</p>
                          {doc.permission === "family" && (
                            <span className="text-[10px] uppercase font-bold tracking-wider bg-purple-900 border border-purple-500 text-purple-200 px-2 py-0.5 rounded">
                              Family
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">
                          {doc.category}
                          {doc.fileName && ` • ${doc.fileName}`}
                          {doc.fileSize ? ` • ${formatBytes(doc.fileSize)}` : ""}
                          {doc.expiryDate && (
                            <span className="text-amber-300 ml-1">
                              (expires {doc.expiryDate})
                            </span>
                          )}
                        </p>
                      </div>
                      <Link
                        to={`/documents/${doc.id}`}
                        className="text-sm font-semibold text-yellow-300 hover:text-yellow-100 hover:underline shrink-0"
                      >
                        View Details →
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Dashboard;

