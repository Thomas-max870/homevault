
import React, { useEffect, useState } from "react";
import NavBar from "./NavBar";
import { api, ActivityItem } from "../api";
import { useAuth } from "../contexts/AuthContext";

const ActivityLog: React.FC = () => {
  const { user } = useAuth();
  const [events, setEvents] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        setLoading(true);
        const records = await api.getActivities(user?.id);
        setEvents(records);
      } catch (err: any) {
        console.error("Failed to load activity history:", err);
        setError("Failed to load activity log.");
      } finally {
        setLoading(false);
      }
    };

    fetchActivities();
  }, [user?.id]);

  const formatTimestamp = (ts: string | number) => {
    if (!ts) return "";
    try {
      const d = typeof ts === "number" ? new Date(ts) : new Date(ts);
      return d.toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      });
    } catch {
      return String(ts);
    }
  };

  const getActionBadgeColor = (action: string) => {
    const act = action.toLowerCase();
    if (act.includes("upload")) return "bg-green-900 border-green-600 text-green-200";
    if (act.includes("delete")) return "bg-red-900 border-red-600 text-red-200";
    if (act.includes("download")) return "bg-blue-900 border-blue-600 text-blue-200";
    if (act.includes("invite") || act.includes("family")) return "bg-purple-900 border-purple-600 text-purple-200";
    return "bg-slate-700 border-slate-600 text-slate-200";
  };

  return (
    <div className="min-h-screen bg-navy text-white">
      <NavBar />

      <main className="container mx-auto max-w-4xl px-4 py-8">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-yellow-300">
            Activity History & Audit Log
          </h2>
          <p className="text-sm text-slate-300 mt-1">
            Real-time audit trail of vault operations including document uploads, downloads, deletions, and invitations.
          </p>
        </div>

        {error && (
          <div className="rounded-xl border border-red-800 bg-red-950 p-4 text-red-300 mb-6">
            {error}
          </div>
        )}

        {loading ? (
          <div className="rounded-xl border border-slate-600 bg-slate-800 p-8 text-center text-slate-300">
            Loading activity history...
          </div>
        ) : events.length === 0 ? (
          <div className="rounded-xl border border-slate-600 bg-slate-800 p-8 text-center">
            <p className="font-medium text-slate-200">
              No activity recorded yet in this vault.
            </p>
          </div>
        ) : (
          <ul className="space-y-3">
            {events.map((event, index) => (
              <li
                key={event.id ? String(event.id) : `activity-${index}`}
                className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 rounded-xl border border-slate-700 bg-slate-800/90 p-4 shadow transition-colors hover:border-yellow-400"
              >
                <div className="flex items-start gap-3">
                  <span
                    className={`mt-0.5 px-2.5 py-0.5 text-xs font-semibold rounded border uppercase tracking-wider ${getActionBadgeColor(
                      event.action
                    )}`}
                  >
                    {event.action}
                  </span>
                  <div>
                    <p className="font-semibold text-white">
                      {event.documentTitle ? `"${event.documentTitle}"` : event.action}
                    </p>
                    {event.details && (
                      <p className="text-xs text-slate-400 mt-0.5">{event.details}</p>
                    )}
                  </div>
                </div>

                <div className="text-right text-xs text-slate-400 shrink-0">
                  {formatTimestamp(event.timestamp)}
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
};

export default ActivityLog;

