// src/components/CategoriesPage.tsx
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import NavBar from "./NavBar";

// Helper to convert a display name to a URL‑friendly slug.
const slugify = (text: string) =>
  text.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9\-]/g, "");

const CategoriesPage: React.FC = () => {
  const [categories, setCategories] = useState<string[]>([]);

  useEffect(() => {
    const fetch = async () => {
      const cats = await api.getCategories();
      setCategories(cats);
    };
    fetch();
  }, []);

  return (
    <div>
      <NavBar />
      <div className="container py-8 max-w-4xl">
        <h2 className="text-2xl font-semibold mb-4 text-navy">All Categories</h2>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {categories.map((cat) => (
            <li key={cat} className="bg-gray-800 rounded p-4 shadow hover:bg-gray-700">
              <Link
                to={`/categories/${slugify(cat)}`}
                className="block text-gold font-medium hover:underline"
              >
                {cat}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default CategoriesPage;
