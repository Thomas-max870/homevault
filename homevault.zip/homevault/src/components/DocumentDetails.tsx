// src/components/DocumentDetails.tsx
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { api, DocumentItem } from "../api";
import { useAuth } from "../contexts/AuthContext";
import NavBar from "./NavBar";

const formatSize = (bytes?: number) => {
  if (!bytes) return "-";
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  return `${mb.toFixed(1)} MB`;
};

const DocumentDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [doc, setDoc] = useState<DocumentItem | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string>("");
  const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
  const [deleting, setDeleting] = useState<boolean>(false);
  const [showPreviewModal, setShowPreviewModal] = useState<boolean>(false);
  const [previewUrl, setPreviewUrl] = useState<string>("");

  useEffect(() => {
    const fetch = async () => {
      try {
        setLoading(true);
        if (!id) return;
        const fetched = await api.getDocumentById(id, user?.id);
        setDoc(fetched || null);
      } catch (err: any) {
        console.error("Failed to load document:", err);
        setError("Failed to load document details.");
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [id, user?.id]);

  const handleDownload = async () => {
    if (!doc) return;
    try {
      setError("");
      const result = await api.downloadDocumentFile(doc, user ? { id: user.id } : undefined);
      if (result.url) {
        window.open(result.url, "_blank");
      } else if (result.blob) {
        const url = URL.createObjectURL(result.blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = result.fileName;
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch (e: any) {
      console.error(e);
      setError(e?.message || "Failed to download file.");
    }
  };

  const handleOpenPreview = async () => {
    if (!doc) return;
    setError("");

    if (doc.fileId) {
      const url = api.getFilePreviewUrl(doc.fileId);
      if (url) {
        setPreviewUrl(url);
        setShowPreviewModal(true);
        return;
      }
    }

    // Try blob preview fallback
    try {
      const result = await api.downloadDocumentFile(doc, user ? { id: user.id } : undefined);
      if (result.blob) {
        const blobUrl = URL.createObjectURL(result.blob);
        setPreviewUrl(blobUrl);
        setShowPreviewModal(true);
      } else if (result.url) {
        setPreviewUrl(result.url);
        setShowPreviewModal(true);
      }
    } catch (err: any) {
      setError("Preview is not available for this file type or offline document.");
    }
  };

  const handleDelete = async () => {
    if (!doc) return;
    setDeleting(true);
    setError("");
    try {
      await api.deleteDocument(doc, user?.id);
      navigate("/dashboard");
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Failed to delete document.");
      setDeleting(false);
      setShowDeleteModal(false);
    }
  };

  const isOwner = !doc?.userId || (user && doc.userId === user.id);

  if (loading) {
    return (
      <div className="min-h-screen bg-navy text-white">
        <NavBar />
        <div className="container py-8 max-w-2xl">
          <p className="text-slate-300">Loading document details...</p>
        </div>
      </div>
    );
  }

  if (!doc) {
    return (
      <div className="min-h-screen bg-navy text-white">
        <NavBar />
        <div className="container py-8 max-w-2xl">
          <p className="text-slate-300">Document not found.</p>
          <button
            className="mt-4 px-4 py-2 bg-slate-700 text-white rounded hover:bg-gold"
            onClick={() => navigate("/dashboard")}
          >
            Back to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const isImage = doc.fileType?.startsWith("image/") || doc.fileName?.match(/\.(jpe?g|png|webp)$/i);
  const isPdf = doc.fileType === "application/pdf" || doc.fileName?.endsWith(".pdf");

  return (
    <div className="min-h-screen bg-navy text-white">
      <NavBar />
      <div className="container py-8 max-w-3xl">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-3xl font-bold text-yellow-300">Document Details</h2>
          <span
            className={`px-3 py-1 rounded text-xs font-semibold ${
              doc.permission === "family"
                ? "bg-purple-900 text-purple-200 border border-purple-500"
                : "bg-slate-700 text-slate-200 border border-slate-600"
            }`}
          >
            {doc.permission === "family" ? "Family Shared" : "Private"}
          </span>
        </div>

        <div className="bg-slate-800 border border-slate-600 rounded-xl p-6 shadow-lg mb-6">
          <dl className="grid grid-cols-1 md:grid-cols-2 gap-4 text-slate-200">
            <div>
              <dt className="text-sm text-slate-400">Title</dt>
              <dd className="text-lg font-semibold text-white">{doc.title}</dd>
            </div>
            <div>
              <dt className="text-sm text-slate-400">Category</dt>
              <dd className="font-medium text-yellow-300">{doc.category}</dd>
            </div>
            {doc.relatedPerson && (
              <div>
                <dt className="text-sm text-slate-400">Related Person</dt>
                <dd>{doc.relatedPerson}</dd>
              </div>
            )}
            {doc.date && (
              <div>
                <dt className="text-sm text-slate-400">Document Date</dt>
                <dd>{doc.date}</dd>
              </div>
            )}
            {doc.expiryDate && (
              <div>
                <dt className="text-sm text-slate-400">Expiry Date</dt>
                <dd className="text-red-300 font-medium">{doc.expiryDate}</dd>
              </div>
            )}
            {doc.fileName && (
              <div>
                <dt className="text-sm text-slate-400">File Name</dt>
                <dd className="break-all">{doc.fileName}</dd>
              </div>
            )}
            {doc.fileSize && (
              <div>
                <dt className="text-sm text-slate-400">File Size</dt>
                <dd>{formatSize(doc.fileSize)}</dd>
              </div>
            )}
            {doc.createdAt && (
              <div>
                <dt className="text-sm text-slate-400">Uploaded</dt>
                <dd>{new Date(doc.createdAt).toLocaleDateString()}</dd>
              </div>
            )}
          </dl>

          {doc.notes && (
            <div className="mt-4 pt-4 border-t border-slate-700">
              <dt className="text-sm text-slate-400 mb-1">Notes</dt>
              <dd className="text-slate-200 bg-slate-900 p-3 rounded">{doc.notes}</dd>
            </div>
          )}
        </div>

        {error && <p className="text-red-300 bg-red-950 border border-red-800 p-3 rounded mb-4">{error}</p>}

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleOpenPreview}
            className="px-4 py-2 bg-yellow-400 text-slate-900 font-semibold rounded hover:bg-yellow-300 transition-colors"
          >
            Preview File
          </button>

          <button
            onClick={handleDownload}
            className="px-4 py-2 bg-slate-700 text-white rounded hover:bg-slate-600 transition-colors"
          >
            Download
          </button>

          {isOwner && (
            <button
              onClick={() => setShowDeleteModal(true)}
              className="px-4 py-2 bg-red-800 text-white rounded hover:bg-red-700 transition-colors"
            >
              Delete Document
            </button>
          )}

          <button
            onClick={() => navigate("/dashboard")}
            className="px-4 py-2 border border-slate-500 rounded text-slate-300 hover:bg-slate-800"
          >
            Back to Dashboard
          </button>
        </div>

        {/* Delete Confirmation Modal */}
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
            <div className="w-full max-w-md bg-slate-800 border border-slate-600 rounded-xl p-6 shadow-2xl text-white">
              <h3 className="text-xl font-bold text-red-400 mb-2">Delete Document</h3>
              <p className="text-slate-300 text-sm mb-4">
                Are you sure you want to permanently delete <strong>{doc.title}</strong>? This action will remove the cloud file and metadata. This cannot be undone.
              </p>
              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  disabled={deleting}
                  onClick={() => setShowDeleteModal(false)}
                  className="px-4 py-2 border border-slate-500 rounded text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={deleting}
                  onClick={handleDelete}
                  className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded font-medium disabled:opacity-50"
                >
                  {deleting ? "Deleting..." : "Permanently Delete"}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* File Preview Modal */}
        {showPreviewModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
            <div className="relative w-full max-w-4xl max-h-[90vh] bg-slate-900 border border-slate-700 rounded-xl flex flex-col overflow-hidden shadow-2xl">
              <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
                <h3 className="text-lg font-semibold text-white">{doc.title} — Preview</h3>
                <button
                  onClick={() => setShowPreviewModal(false)}
                  className="text-slate-400 hover:text-white text-2xl leading-none"
                  aria-label="Close Preview"
                >
                  &times;
                </button>
              </div>
              <div className="flex-1 overflow-auto p-4 flex items-center justify-center min-h-[400px]">
                {isImage ? (
                  <img
                    src={previewUrl}
                    alt={doc.title}
                    className="max-w-full max-h-[75vh] object-contain rounded"
                  />
                ) : isPdf ? (
                  <iframe
                    src={previewUrl}
                    title={doc.title}
                    className="w-full h-[75vh] rounded border-0"
                  />
                ) : (
                  <div className="text-center p-8">
                    <p className="text-slate-300 mb-4">
                      Direct in-browser preview is not supported for this file format.
                    </p>
                    <button
                      onClick={handleDownload}
                      className="px-4 py-2 bg-yellow-400 text-slate-900 font-semibold rounded hover:bg-yellow-300"
                    >
                      Download to View
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DocumentDetails;

