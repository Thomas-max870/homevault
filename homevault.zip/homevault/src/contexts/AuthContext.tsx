// src/contexts/AuthContext.tsx
// React context providing authentication state to the entire HomeVault app.

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from "react";
import { authBackend, AuthUser, RegisterResult } from "../authBackend";

// ========================================
// CONTEXT TYPE
// ========================================

interface AuthContextType {
  /** The currently authenticated user, or null. */
  user: AuthUser | null;

  /** True while checking for an existing session on mount. */
  loading: boolean;

  /** Whether a real auth provider is connected. */
  isConfigured: boolean;

  /** Sign in. Throws on failure. */
  login: (email: string, password: string, remember?: boolean) => Promise<void>;

  /** Create a new account and trigger verification. Does NOT sign in. */
  register: (name: string, email: string, password: string) => Promise<RegisterResult>;

  /** Sign out. Clears user state. */
  logout: () => Promise<void>;

  /** Request a password recovery email. */
  sendPasswordRecovery: (email: string) => Promise<void>;

  /** Complete password recovery with token from email. */
  completePasswordRecovery: (
    userId: string,
    secret: string,
    newPassword: string,
    confirmPassword: string
  ) => Promise<void>;

  /** Change the current user's password. */
  changePassword: (
    currentPassword: string,
    newPassword: string
  ) => Promise<void>;

  /** Send an email verification message. */
  sendEmailVerification: () => Promise<void>;

  /** Complete email verification with a token. */
  completeEmailVerification: (userId: string, secret: string) => Promise<void>;

  /** Refreshes current user state from Appwrite session. */
  refreshUser: () => Promise<AuthUser | null>;
}

// ========================================
// CONTEXT
// ========================================

const AuthContext = createContext<AuthContextType | undefined>(undefined);

/**
 * Hook to access the auth context. Must be used inside AuthProvider.
 */
export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider.");
  }
  return context;
}

// ========================================
// PROVIDER
// ========================================

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const isConfigured = authBackend.isConfigured();

  const refreshUser = useCallback(async (): Promise<AuthUser | null> => {
    try {
      const currentUser = await authBackend.getCurrentUser();
      setUser(currentUser);
      return currentUser;
    } catch {
      setUser(null);
      return null;
    }
  }, []);

  // Check for an existing session on mount.
  useEffect(() => {
    let cancelled = false;

    const checkSession = async () => {
      try {
        const currentUser = await authBackend.getCurrentUser();
        if (!cancelled) {
          setUser(currentUser);
        }
      } catch {
        if (!cancelled) {
          setUser(null);
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    checkSession();

    return () => {
      cancelled = true;
    };
  }, []);

  const login = useCallback(
    async (email: string, password: string, remember?: boolean) => {
      const authedUser = await authBackend.login(email, password, remember);
      setUser(authedUser);
    },
    []
  );

  const register = useCallback(
    async (name: string, email: string, password: string): Promise<RegisterResult> => {
      return await authBackend.register(name, email, password);
    },
    []
  );

  const logout = useCallback(async () => {
    await authBackend.logout();
    setUser(null);
  }, []);

  const sendPasswordRecovery = useCallback(async (email: string) => {
    await authBackend.sendPasswordRecovery(email);
  }, []);

  const completePasswordRecovery = useCallback(
    async (
      userId: string,
      secret: string,
      newPassword: string,
      confirmPassword: string
    ) => {
      await authBackend.completePasswordRecovery(
        userId,
        secret,
        newPassword,
        confirmPassword
      );
    },
    []
  );

  const changePassword = useCallback(
    async (currentPassword: string, newPassword: string) => {
      await authBackend.changePassword(currentPassword, newPassword);
    },
    []
  );

  const sendEmailVerification = useCallback(async () => {
    await authBackend.sendEmailVerification();
  }, []);

  const completeEmailVerification = useCallback(
    async (userId: string, secret: string) => {
      await authBackend.completeEmailVerification(userId, secret);
      // Only refresh user if a session was already active to avoid 401 on guest verification
      if (user) {
        await refreshUser();
      }
    },
    [user, refreshUser]
  );

  const value: AuthContextType = {
    user,
    loading,
    isConfigured,
    login,
    register,
    logout,
    sendPasswordRecovery,
    completePasswordRecovery,
    changePassword,
    sendEmailVerification,
    completeEmailVerification,
    refreshUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
