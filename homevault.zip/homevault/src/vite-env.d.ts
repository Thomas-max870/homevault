/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_APPWRITE_ENDPOINT: string;
  readonly VITE_APPWRITE_PROJECT_ID: string;
  readonly VITE_APPWRITE_DATABASE_ID?: string;
  readonly VITE_APPWRITE_COLLECTION_DOCUMENTS?: string;
  readonly VITE_APPWRITE_COLLECTION_SETTINGS?: string;
  readonly VITE_APPWRITE_COLLECTION_ACTIVITIES?: string;
  readonly VITE_APPWRITE_BUCKET_ID?: string;
  readonly VITE_APPWRITE_TEAM_ID?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
