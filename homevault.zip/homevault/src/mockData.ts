// src/mockData.ts
export interface Document {
  id: string;
  title: string;
  category: string;
  relatedPerson?: string;
  date?: string; // ISO date string
  expiryDate?: string; // ISO date string
  notes?: string;
  // In a real app this would be a file URL or blob
  fileName: string;
  sharedWith: string[]; // array of member IDs (mock)
}

export const categories = [
  "Identity Documents",
  "Birth and Family Certificates",
  "Educational Documents",
  "Banking and Financial Documents",
  "Property and Land Documents",
  "Insurance Documents",
  "Medical Documents",
  "Employment and Professional Documents",
  "Vehicle Documents",
  "Utility and Household Documents",
  "Pension and Government Benefits",
  "Religious and Personal Certificates",
  "Other Documents",
];

export const documents: Document[] = [
  {
    id: "doc-1",
    title: "Passport",
    category: "Identity Documents",
    date: "2023-01-15",
    fileName: "passport.pdf",
    sharedWith: [],
  },
  {
    id: "doc-2",
    title: "Birth Certificate",
    category: "Birth and Family Certificates",
    date: "2020-06-01",
    fileName: "birth_certificate.pdf",
    sharedWith: [],
  },
  {
    id: "doc-3",
    title: "University Degree",
    category: "Educational Documents",
    date: "2022-05-20",
    fileName: "degree.pdf",
    sharedWith: [],
  },
  // add more mock items as needed
];
