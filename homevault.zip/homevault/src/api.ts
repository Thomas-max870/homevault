// src/api.ts
// HomeVault API layer: Appwrite Cloud with IndexedDB fallback.
// IMPORTANT: Cloud document fields must match the existing Appwrite schema.

import { categories as mockCategories } from "./mockData";
import {
  databases,
  storage,
  teams,
  appwriteConfig,
  isAppwriteConfigured,
  ID,
  Permission,
  Role,
  Query,
  account,
} from "./lib/appwrite";
import {
  getAllDocuments as idbGetAllDocuments,
  addDocument as idbAddDocument,
  getDocument as idbGetDocument,
  saveFileBlob as idbSaveFileBlob,
  getFileBlob as idbGetFileBlob,
  getSettings as idbGetSettings,
  saveSettings as idbSaveSettings,
  addActivity as idbAddActivity,
  getActivities as idbGetActivities,
  deleteDocument as idbDeleteDocument,
  getAllFilesSize as idbGetAllFilesSize,
  type IDBDocument,
} from "./idb";

export type DocumentPermission = "private" | "family" | "public";

export interface DocumentItem {
  id: string;
  title: string;
  category: string;
  relatedPerson?: string;
  date?: string;
  expiryDate?: string;
  notes?: string;
  fileId?: string;
  fileName?: string;
  fileSize?: number;
  fileType?: string;
  userId?: string;
  permission?: DocumentPermission;
  sharedWith?: string[];
  createdAt?: string;
  [key: string]: unknown;
}

// Explicit input type avoids Omit + index-signature turning known fields into unknown.
export interface NewDocumentInput {
  title: string;
  category: string;
  relatedPerson?: string;
  date?: string;
  expiryDate?: string;
  notes?: string;
  userId?: string;
  permission?: DocumentPermission;
}

export interface ActivityItem {
  id?: string | number;
  action: string;
  documentTitle?: string;
  documentId?: string;
  userId?: string;
  timestamp: string | number;
  details?: string;
}

export interface TeamMemberItem {
  id: string;
  name: string;
  email: string;
  roles: string[];
  invited: string;
  joined: string;
  status: boolean;
}

export const ALLOWED_FILE_TYPES = [
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/webp",
];

export const MAX_FILE_SIZE_BYTES = 25 * 1024 * 1024;

function normalizePermission(value: unknown): DocumentPermission {
  return value === "family" || value === "public" ? value : "private";
}

/**
 * The current Appwrite documents table has these custom columns:
 * title, category, notes, fileId, fileType, userId, permission, fileSize
 *
 * Do not send relatedPerson, date, expiryDate, fileName, or fileSize as
 * separate Appwrite attributes until those columns have been created.
 */
function mapCloudDocument(doc: any): DocumentItem {
  return {
    id: String(doc.$id),
    title: String(doc.title ?? ""),
    category: String(doc.category ?? ""),
    notes: typeof doc.notes === "string" ? doc.notes : "",
    fileId: typeof doc.fileId === "string" ? doc.fileId : undefined,
    fileName: undefined,
    fileSize: typeof doc.fileSize === "number" ? doc.fileSize : undefined,
    fileType: typeof doc.fileType === "string" ? doc.fileType : undefined,
    userId: typeof doc.userId === "string" ? doc.userId : undefined,
    permission: normalizePermission(doc.permission),
    sharedWith: [],
    createdAt: doc.$createdAt,
  };
}

function mapLocalDocument(doc: IDBDocument): DocumentItem {
  return {
    id: doc.id,
    title: doc.title,
    category: doc.category,
    relatedPerson: typeof doc.relatedPerson === "string" ? doc.relatedPerson : undefined,
    date: typeof doc.date === "string" ? doc.date : undefined,
    expiryDate: typeof doc.expiryDate === "string" ? doc.expiryDate : undefined,
    notes: typeof doc.notes === "string" ? doc.notes : undefined,
    fileId: typeof doc.fileId === "string" ? doc.fileId : undefined,
    fileName: typeof doc.fileName === "string" ? doc.fileName : undefined,
    fileSize: typeof doc.fileSize === "number" ? doc.fileSize : undefined,
    fileType: typeof doc.fileType === "string" ? doc.fileType : undefined,
    userId: typeof doc.userId === "string" ? doc.userId : undefined,
    permission: normalizePermission(doc.permission),
    sharedWith: Array.isArray(doc.sharedWith) ? doc.sharedWith.filter((x): x is string => typeof x === "string") : [],
    createdAt: typeof doc.createdAt === "string" ? doc.createdAt : undefined,
  };
}

export const api = {
  // DOCUMENTS ---------------------------------------------------------------
  getDocuments: async (currentUserId?: string): Promise<DocumentItem[]> => {
    if (isAppwriteConfigured && currentUserId) {
      try {
        const response = await databases.listDocuments(
          appwriteConfig.databaseId,
          appwriteConfig.documentsCollectionId,
          [
            Query.equal("userId", currentUserId),
            Query.orderDesc("$createdAt"),
            Query.limit(100),
          ]
        );
        return response.documents.map(mapCloudDocument);
      } catch (err: any) {
        console.warn("Appwrite getDocuments failed; checking local storage:", err?.message || err);
      }
    }

    const localDocs = await idbGetAllDocuments();
    return localDocs
      .filter((doc) => !currentUserId || !doc.userId || doc.userId === currentUserId)
      .map(mapLocalDocument);
  },

  getCategories: async (): Promise<string[]> => [...mockCategories],

  addDocument: async (
    doc: NewDocumentInput,
    file: File,
    currentUser?: { id: string; email: string }
  ): Promise<DocumentItem> => {
    if (!ALLOWED_FILE_TYPES.includes(file.type)) {
      throw new Error(
        `Unsupported file type: ${file.type || "unknown"}. Only PDF, JPEG, PNG, and WebP are allowed.`
      );
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      throw new Error(
        `File is too large (${(file.size / (1024 * 1024)).toFixed(1)} MB). Maximum allowed size is 25 MB.`
      );
    }

    if (isAppwriteConfigured && currentUser?.id) {
      await account.get();

      const userId = currentUser.id;
      const permission = normalizePermission(doc.permission);
      const fileId = ID.unique();

      const filePermissions = [
        Permission.read(Role.user(userId)),
        Permission.update(Role.user(userId)),
        Permission.delete(Role.user(userId)),
      ];

      const documentPermissions = [
        Permission.read(Role.user(userId)),
        Permission.update(Role.user(userId)),
        Permission.delete(Role.user(userId)),
      ];

      if (permission === "family" && appwriteConfig.familyTeamId) {
        documentPermissions.push(Permission.read(Role.team(appwriteConfig.familyTeamId)));
      }

      const uploadedFile = await storage.createFile(
        appwriteConfig.storageBucketId,
        fileId,
        file,
        filePermissions
      );

      try {
        // Send only attributes that exist in the Appwrite documents table.
        const createdDoc = await databases.createDocument(
          appwriteConfig.databaseId,
          appwriteConfig.documentsCollectionId,
          ID.unique(),
          {
            title: doc.title,
            category: doc.category,
            notes: doc.notes || null,
            fileId: uploadedFile.$id,
            fileType: file.type,
            userId,
            permission,
            fileSize: file.size,
          },
          documentPermissions
        );

        await api.recordActivity(
          {
            action: "Document uploaded",
            documentTitle: String(createdDoc.title ?? doc.title),
            documentId: createdDoc.$id,
            userId,
            details: `Uploaded ${file.name} (${(file.size / 1024).toFixed(1)} KB)`,
          },
          userId
        );

        return {
          ...mapCloudDocument(createdDoc),
          fileName: file.name,
          fileSize: file.size,
          fileType: file.type,
          // These fields are not cloud columns in the current schema.
          relatedPerson: typeof doc.relatedPerson === "string" ? doc.relatedPerson : undefined,
          date: typeof doc.date === "string" ? doc.date : undefined,
          expiryDate: typeof doc.expiryDate === "string" ? doc.expiryDate : undefined,
        };
      } catch (dbErr: any) {
        try {
          await storage.deleteFile(appwriteConfig.storageBucketId, uploadedFile.$id);
        } catch (cleanupErr) {
          console.error("Could not remove uploaded file after metadata failure:", cleanupErr);
        }
        throw new Error(`Failed to save document metadata: ${dbErr?.message || dbErr}`);
      }
    }

    // Local-only fallback. This is browser storage, not cloud backup.
    const localPermission = normalizePermission(doc.permission);
    const storedMeta = await idbAddDocument({
      title: doc.title,
      category: doc.category,
      relatedPerson: typeof doc.relatedPerson === "string" ? doc.relatedPerson : undefined,
      date: typeof doc.date === "string" ? doc.date : undefined,
      expiryDate: typeof doc.expiryDate === "string" ? doc.expiryDate : undefined,
      notes: typeof doc.notes === "string" ? doc.notes : undefined,
      userId: currentUser?.id || "anonymous",
      permission: localPermission,
      sharedWith: [],
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
      createdAt: new Date().toISOString(),
    });
    await idbSaveFileBlob(storedMeta.id, file);
    await idbAddActivity({
      type: "upload",
      documentId: storedMeta.id,
      details: `Uploaded ${file.name}`,
    });
    return mapLocalDocument(storedMeta);
  },

  getDocumentById: async (id: string, currentUserId?: string): Promise<DocumentItem | undefined> => {
    if (isAppwriteConfigured && currentUserId) {
      try {
        const doc: any = await databases.getDocument(
          appwriteConfig.databaseId,
          appwriteConfig.documentsCollectionId,
          id
        );
        if (doc.userId !== currentUserId && doc.permission !== "family" && doc.permission !== "public") {
          throw new Error("You do not have permission to view this document.");
        }
        return mapCloudDocument(doc);
      } catch (err: any) {
        console.warn("Appwrite getDocumentById failed; checking local storage:", err?.message || err);
      }
    }
    const local = await idbGetDocument(id);
    if (!local) return undefined;
    if (currentUserId && local.userId && local.userId !== currentUserId) return undefined;
    return mapLocalDocument(local);
  },

  getFilePreviewUrl: (fileId: string): string => {
    if (!isAppwriteConfigured) return "";
    return storage.getFileView(appwriteConfig.storageBucketId, fileId).toString();
  },

  getFileDownloadUrl: (fileId: string): string => {
    if (!isAppwriteConfigured) return "";
    return storage.getFileDownload(appwriteConfig.storageBucketId, fileId).toString();
  },

  downloadDocumentFile: async (
    doc: DocumentItem,
    currentUser?: { id: string }
  ): Promise<{ blob?: Blob; url?: string; fileName: string }> => {
    const fileName = doc.fileName || `${doc.title || "document"}.bin`;

    if (isAppwriteConfigured && doc.fileId) {
      const url = storage.getFileDownload(appwriteConfig.storageBucketId, doc.fileId).toString();
      if (currentUser?.id) {
        await api.recordActivity(
          {
            action: "Document downloaded",
            documentTitle: doc.title,
            documentId: doc.id,
            userId: currentUser.id,
            details: `Downloaded ${fileName}`,
          },
          currentUser.id
        );
      }
      return { url, fileName };
    }

    const blob = await idbGetFileBlob(doc.id);
    if (!blob) throw new Error("File contents are not available in local storage.");
    await idbAddActivity({
      type: "download",
      documentId: doc.id,
      details: `Downloaded ${fileName}`,
    });
    return { blob, fileName };
  },

  deleteDocument: async (doc: DocumentItem, currentUserId?: string): Promise<void> => {
    if (isAppwriteConfigured && currentUserId) {
      const existing = await databases.getDocument(
        appwriteConfig.databaseId,
        appwriteConfig.documentsCollectionId,
        doc.id
      ) as any;

      if (existing.userId !== currentUserId) {
        throw new Error("You do not have permission to delete this document.");
      }

      if (existing.fileId) {
        try {
          await storage.deleteFile(appwriteConfig.storageBucketId, existing.fileId);
        } catch (err: any) {
          // Continue to remove metadata only if the file is already gone.
          if (err?.code !== 404) throw err;
        }
      }

      await databases.deleteDocument(
        appwriteConfig.databaseId,
        appwriteConfig.documentsCollectionId,
        doc.id
      );
      await api.recordActivity(
        {
          action: "Document deleted",
          documentTitle: doc.title,
          documentId: doc.id,
          userId: currentUserId,
          details: `Deleted ${doc.title}`,
        },
        currentUserId
      );
      return;
    }

    await idbDeleteDocument(doc.id);
    await idbAddActivity({
      type: "delete",
      documentId: doc.id,
      details: `Deleted document ${doc.title}`,
    });
  },

  // SETTINGS -----------------------------------------------------------------
  getSettings: async (
    currentUserId?: string
  ): Promise<{ vaultName: string; members: string[] }> => {
    if (isAppwriteConfigured && currentUserId) {
      try {
        const response = await databases.listDocuments(
          appwriteConfig.databaseId,
          appwriteConfig.settingsCollectionId,
          [Query.equal("ownerId", currentUserId), Query.limit(1)]
        );
        if (response.documents.length > 0) {
          const settings: any = response.documents[0];
          return { vaultName: String(settings.vaultName ?? ""), members: [] };
        }
      } catch (err: any) {
        console.warn("Appwrite getSettings failed; checking local storage:", err?.message || err);
      }
    }
    const settings = await idbGetSettings();
    return { vaultName: settings?.vaultName ?? "", members: settings?.members ?? [] };
  },

  saveSettings: async (
    vaultName: string,
    members: string[],
    currentUserId?: string
  ): Promise<{ vaultName: string; members: string[] }> => {
    if (isAppwriteConfigured && currentUserId) {
      const existing = await databases.listDocuments(
        appwriteConfig.databaseId,
        appwriteConfig.settingsCollectionId,
        [Query.equal("ownerId", currentUserId), Query.limit(1)]
      );

      const permissions = [
        Permission.read(Role.user(currentUserId)),
        Permission.update(Role.user(currentUserId)),
        Permission.delete(Role.user(currentUserId)),
      ];

      if (existing.documents.length > 0) {
        await databases.updateDocument(
          appwriteConfig.databaseId,
          appwriteConfig.settingsCollectionId,
          existing.documents[0].$id,
          { vaultName }
        );
      } else {
        await databases.createDocument(
          appwriteConfig.databaseId,
          appwriteConfig.settingsCollectionId,
          ID.unique(),
          { vaultName, ownerId: currentUserId },
          permissions
        );
      }

      await api.recordActivity(
        {
          action: "Vault settings updated",
          userId: currentUserId,
          details: `Vault name set to ${vaultName}`,
        },
        currentUserId
      );
      return { vaultName, members };
    }

    const saved = await idbSaveSettings({ vaultName, members });
    return { vaultName: saved.vaultName, members: saved.members };
  },

  // FAMILY TEAM ----------------------------------------------------------------
  getFamilyMembers: async (): Promise<TeamMemberItem[]> => {
    if (!isAppwriteConfigured || !appwriteConfig.familyTeamId) return [];
    try {
      const response = await teams.listMemberships(appwriteConfig.familyTeamId);
      return response.memberships.map((m: any) => ({
        id: m.$id,
        name: m.userName || m.userEmail || "Family member",
        email: m.userEmail || "",
        roles: m.roles || [],
        invited: m.invited || "",
        joined: m.joined || "",
        status: Boolean(m.joined),
      }));
    } catch (err: any) {
      console.warn("Appwrite getFamilyMembers failed:", err?.message || err);
      return [];
    }
  },

  inviteFamilyMember: async (
    email: string,
    role = "member",
    currentUserId?: string
  ): Promise<any> => {
    if (!isAppwriteConfigured || !appwriteConfig.familyTeamId) {
      throw new Error("Appwrite Teams is not configured for family collaboration.");
    }
    const redirectUrl = typeof window !== "undefined"
      ? `${window.location.origin}/settings`
      : "http://localhost:5173/settings";

    const membership = await teams.createMembership(
      appwriteConfig.familyTeamId,
      [role],
      email,
      undefined,
      undefined,
      redirectUrl
    );

    if (currentUserId) {
      await api.recordActivity(
        {
          action: "Family member invited",
          userId: currentUserId,
          details: `Invited ${email} as ${role}`,
        },
        currentUserId
      );
    }
    return membership;
  },

  removeFamilyMember: async (membershipId: string, currentUserId?: string): Promise<void> => {
    if (!isAppwriteConfigured || !appwriteConfig.familyTeamId) {
      throw new Error("Appwrite Teams is not configured.");
    }
    await teams.deleteMembership(appwriteConfig.familyTeamId, membershipId);
    if (currentUserId) {
      await api.recordActivity(
        {
          action: "Family member removed",
          userId: currentUserId,
          details: `Removed membership ${membershipId}`,
        },
        currentUserId
      );
    }
  },

  // ACTIVITY -----------------------------------------------------------------
  getActivities: async (currentUserId?: string): Promise<ActivityItem[]> => {
    if (isAppwriteConfigured && currentUserId) {
      try {
        const response = await databases.listDocuments(
          appwriteConfig.databaseId,
          appwriteConfig.activitiesCollectionId,
          [
            Query.equal("userId", currentUserId),
            Query.orderDesc("$createdAt"),
            Query.limit(50),
          ]
        );
        return response.documents.map((act: any) => ({
          id: act.$id,
          action: String(act.action ?? ""),
          documentTitle: typeof act.documentTitle === "string" ? act.documentTitle : undefined,
          userId: typeof act.userId === "string" ? act.userId : undefined,
          timestamp: act.timestamp || act.$createdAt,
        }));
      } catch (err: any) {
        console.warn("Appwrite getActivities failed; checking local activity log:", err?.message || err);
      }
    }

    const local = await idbGetActivities();
    return local.map((activity) => ({
      id: activity.id,
      action:
        activity.type === "upload" ? "Document uploaded" :
        activity.type === "download" ? "Document downloaded" :
        activity.type === "delete" ? "Document deleted" :
        "Settings updated",
      documentId: activity.documentId,
      timestamp: activity.timestamp,
      details: activity.details,
    }));
  },

  recordActivity: async (
    item: {
      action: string;
      documentTitle?: string;
      documentId?: string;
      userId: string;
      details?: string;
    },
    currentUserId?: string
  ): Promise<void> => {
    if (isAppwriteConfigured && currentUserId) {
      try {
        // Current Appwrite activities table columns are action, documentTitle,
        // userId, timestamp. Do not send unsupported documentId/details columns.
        await databases.createDocument(
          appwriteConfig.databaseId,
          appwriteConfig.activitiesCollectionId,
          ID.unique(),
          {
            action: item.action,
            documentTitle: item.documentTitle || null,
            userId: item.userId,
            timestamp: new Date().toISOString(),
          },
          [
            Permission.read(Role.user(currentUserId)),
            Permission.update(Role.user(currentUserId)),
            Permission.delete(Role.user(currentUserId)),
            ...(appwriteConfig.familyTeamId && item.action.startsWith("Document")
              ? [Permission.read(Role.team(appwriteConfig.familyTeamId))]
              : []),
          ]
        );
        return;
      } catch (err: any) {
        console.warn("Could not record activity in Appwrite; using local activity log:", err?.message || err);
      }
    }

    const type =
      item.action.toLowerCase().includes("download") ? "download" :
      item.action.toLowerCase().includes("delete") ? "delete" :
      item.action.toLowerCase().includes("settings") ? "settings_save" :
      "upload";

    await idbAddActivity({
      type,
      documentId: item.documentId,
      details: item.details || item.action,
    });
  },

  // STORAGE USAGE ------------------------------------------------------------
  getStorageUsage: async (
    currentUserId?: string
  ): Promise<{ used: number; quota?: number }> => {
    if (isAppwriteConfigured && currentUserId) {
      const docs = await api.getDocuments(currentUserId);
      return { used: docs.reduce((total, doc) => total + (doc.fileSize || 0), 0) };
    }
    return { used: await idbGetAllFilesSize() };
  },
};
