// src/authBackend.ts
// Provider-agnostic authentication interface for HomeVault with Appwrite integration.
// Connects to the official Appwrite SDK when configured, or falls back to a stub
// that clearly communicates that configuration is required.

import {
  account,
  isAppwriteConfigured,
  AppwriteException,
  ID,
} from "./lib/appwrite";

// ========================================
// TYPES & ERRORS
// ========================================

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  emailVerified: boolean;
}

export interface RegisterResult {
  userId: string;
  verificationSent: boolean;
  message?: string;
}

export class AuthNotConfiguredError extends Error {
  constructor(operation: string) {
    super(
      `Appwrite authentication is not configured. Cannot ${operation}. ` +
      `Please set VITE_APPWRITE_ENDPOINT and VITE_APPWRITE_PROJECT_ID in your .env file.`
    );
    this.name = "AuthNotConfiguredError";
  }
}

/**
 * Resolves the verification redirect URL for Appwrite.
 * Ensures local development reliably routes to http://localhost:5173/verify-email,
 * which matches the registered Appwrite Web platform.
 */
export function getVerificationRedirectUrl(): string {
  if (typeof window !== "undefined") {
    const origin = window.location.origin;
    if (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1") {
      const port = window.location.port ? `:${window.location.port}` : ":5173";
      return `http://localhost${port}/verify-email`;
    }
    return `${origin}/verify-email`;
  }
  return "http://localhost:5173/verify-email";
}

/**
 * Helper to determine if an Appwrite error represents an already-verified state (HTTP 409).
 */
export function isUserAlreadyVerifiedError(err: unknown): boolean {
  if (!err) return false;
  if (err instanceof AppwriteException) {
    if (
      err.code === 409 ||
      err.type === "user_already_verified" ||
      err.message?.toLowerCase().includes("already verified") ||
      err.message?.toLowerCase().includes("already been verified")
    ) {
      return true;
    }
  }

  const anyErr = err as { code?: number; type?: string; message?: string };
  if (
    anyErr?.code === 409 ||
    anyErr?.type === "user_already_verified" ||
    (typeof anyErr?.message === "string" &&
      (anyErr.message.toLowerCase().includes("already verified") ||
        anyErr.message.toLowerCase().includes("already been verified")))
  ) {
    return true;
  }

  return false;
}

/**
 * Converts Appwrite errors into safe, user-friendly messages.
 * Never leaks server details or internal tokens.
 */
export function formatAppwriteError(err: unknown, defaultMessage = "An error occurred"): string {
  if (err instanceof AuthNotConfiguredError) {
    return err.message;
  }

  if (err instanceof AppwriteException) {
    switch (err.type) {
      case "user_invalid_credentials":
        return "Invalid email or password. Please verify your credentials and try again.";
      case "user_already_exists":
      case "user_email_already_exists":
        return "An account with this email address already exists.";
      case "password_recently_used":
        return "You cannot reuse a recently used password.";
      case "password_personal_data":
        return "Your password contains personal information. Please choose a stronger password.";
      case "user_invalid_token":
        return "The verification or reset link is invalid or has expired.";
      case "user_already_verified":
        return "Your email address is already verified.";
      case "general_rate_limit_exceeded":
        return "Too many attempts. Please wait a few minutes before trying again.";
      case "user_blocked":
        return "This account has been blocked. Please contact support.";
      case "user_session_already_exists":
        return "A session already exists. Please log out first.";
      case "user_unauthorized":
        return "You are not authorized to perform this action.";
      default:
        if (err.message && err.message.length < 200) {
          return err.message;
        }
        return defaultMessage;
    }
  }

  if (err instanceof Error) {
    return err.message || defaultMessage;
  }

  return defaultMessage;
}

// ========================================
// AUTH BACKEND INTERFACE
// ========================================

export interface AuthBackend {
  /** Whether a real auth provider is connected. */
  isConfigured(): boolean;

  /** Sign in with email and password. */
  login(email: string, password: string, remember?: boolean): Promise<AuthUser>;

  /** Create a new account. Does NOT grant access to the vault. */
  register(name: string, email: string, password: string): Promise<RegisterResult>;

  /** Sign out the current user. */
  logout(): Promise<void>;

  /** Get the currently authenticated user, or null if no session. */
  getCurrentUser(): Promise<AuthUser | null>;

  /** Send a password recovery email. */
  sendPasswordRecovery(email: string): Promise<void>;

  /** Complete password recovery using a token from the recovery email. */
  completePasswordRecovery(
    userId: string,
    secret: string,
    newPassword: string,
    confirmPassword: string
  ): Promise<void>;

  /** Change the password of the currently authenticated user. */
  changePassword(currentPassword: string, newPassword: string): Promise<void>;

  /** Send an email verification message to the current user. */
  sendEmailVerification(): Promise<void>;

  /** Complete email verification using a token from the verification email. */
  completeEmailVerification(userId: string, secret: string): Promise<void>;
}

// ========================================
// APPWRITE IMPLEMENTATION
// ========================================

const REMEMBER_ME_KEY = "homevault_remember_me";
const SESSION_ACTIVE_KEY = "homevault_session_active";

export class AppwriteAuthBackend implements AuthBackend {
  isConfigured(): boolean {
    return true;
  }

  async login(email: string, password: string, remember = false): Promise<AuthUser> {
    try {
      // If there is already an active session, delete it first to avoid 409 conflict
      try {
        await account.deleteSession("current");
      } catch {
        // No existing session to clear
      }

      await account.createEmailPasswordSession(email, password);

      // Manage remember-me session persistence state
      if (remember) {
        localStorage.setItem(REMEMBER_ME_KEY, "true");
        sessionStorage.setItem(SESSION_ACTIVE_KEY, "true");
      } else {
        localStorage.removeItem(REMEMBER_ME_KEY);
        sessionStorage.setItem(SESSION_ACTIVE_KEY, "true");
      }

      const appwriteUser = await account.get();

      return {
        id: appwriteUser.$id,
        name: appwriteUser.name,
        email: appwriteUser.email,
        emailVerified: Boolean(appwriteUser.emailVerification),
      };
    } catch (err) {
      throw new Error(formatAppwriteError(err, "Sign in failed. Please check your credentials."));
    }
  }

  async register(name: string, email: string, password: string): Promise<RegisterResult> {
    const userId = ID.unique();

    try {
      // 1. Create the Appwrite user account
      await account.create(userId, email, password, name);
    } catch (err) {
      throw new Error(formatAppwriteError(err, "Account creation failed. Please try again."));
    }

    // 2. Initiate email verification flow.
    // In Appwrite, creating an email verification token requires an active session.
    // We create a temporary session, trigger the verification email with the configured
    // callback URL, and immediately delete the session so the user is NOT granted vault access.
    let verificationSent = false;
    let verificationMessage = "";

    try {
      await account.createEmailPasswordSession(email, password);
      const verifyUrl = getVerificationRedirectUrl();
      await account.createEmailVerification(verifyUrl);
      verificationSent = true;
    } catch (verErr) {
      verificationSent = false;
      verificationMessage = formatAppwriteError(
        verErr,
        "Account created, but verification email could not be sent. Please ensure email delivery is configured in your Appwrite Console."
      );
    } finally {
      // Always destroy temporary session so the user cannot bypass login/verification
      try {
        await account.deleteSession("current");
      } catch {
        // Ignored
      }
      // Ensure storage markers are not set for this discarded session
      localStorage.removeItem(REMEMBER_ME_KEY);
      sessionStorage.removeItem(SESSION_ACTIVE_KEY);
    }

    return {
      userId,
      verificationSent,
      message: verificationMessage,
    };
  }

  async logout(): Promise<void> {
    try {
      localStorage.removeItem(REMEMBER_ME_KEY);
      sessionStorage.removeItem(SESSION_ACTIVE_KEY);
      await account.deleteSession("current");
    } catch {
      // Session may already be expired or deleted
    }
  }

  async getCurrentUser(): Promise<AuthUser | null> {
    try {
      const remember = localStorage.getItem(REMEMBER_ME_KEY) === "true";
      const sessionActive = sessionStorage.getItem(SESSION_ACTIVE_KEY) === "true";

      // If neither Remember Me was enabled nor a session marker exists for this tab,
      // the user is not logged in. Avoid calling Appwrite to prevent 401 console errors.
      if (!remember && !sessionActive) {
        return null;
      }

      const appwriteUser = await account.get();

      // Refresh sessionActive marker for the tab
      sessionStorage.setItem(SESSION_ACTIVE_KEY, "true");

      return {
        id: appwriteUser.$id,
        name: appwriteUser.name,
        email: appwriteUser.email,
        emailVerified: Boolean(appwriteUser.emailVerification),
      };
    } catch {
      // Session in Appwrite is expired or invalid -> clear local state
      sessionStorage.removeItem(SESSION_ACTIVE_KEY);
      return null;
    }
  }

  async sendPasswordRecovery(email: string): Promise<void> {
    try {
      const resetUrl = `${window.location.origin}/reset-password`;
      await account.createRecovery(email, resetUrl);
    } catch (err) {
      throw new Error(formatAppwriteError(err, "Failed to send password reset email."));
    }
  }

  async completePasswordRecovery(
    userId: string,
    secret: string,
    newPassword: string,
    confirmPassword: string
  ): Promise<void> {
    if (newPassword !== confirmPassword) {
      throw new Error("Passwords do not match.");
    }
    if (newPassword.length < 8) {
      throw new Error("Password must be at least 8 characters.");
    }

    try {
      await account.updateRecovery(userId, secret, newPassword);
    } catch (err) {
      throw new Error(formatAppwriteError(err, "Password reset failed. The link may be expired or invalid."));
    }
  }

  async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    if (!currentPassword) {
      throw new Error("Current password is required.");
    }
    if (newPassword.length < 8) {
      throw new Error("New password must be at least 8 characters.");
    }
    if (currentPassword === newPassword) {
      throw new Error("New password must be different from current password.");
    }

    try {
      await account.updatePassword(newPassword, currentPassword);
    } catch (err) {
      throw new Error(formatAppwriteError(err, "Failed to update password. Please check your current password."));
    }
  }

  async sendEmailVerification(): Promise<void> {
    try {
      const verifyUrl = getVerificationRedirectUrl();
      await account.createEmailVerification(verifyUrl);
    } catch (err) {
      throw new Error(formatAppwriteError(err, "Failed to send email verification."));
    }
  }

  async completeEmailVerification(userId: string, secret: string): Promise<void> {
    if (!userId || !secret) {
      throw new Error("Missing required verification parameters: userId and secret are required.");
    }

    try {
      // Call Appwrite's account.updateVerification({ userId, secret }) with the configured Account instance
      await account.updateVerification({ userId, secret });
    } catch (err: unknown) {
      // Handle HTTP 409 Conflict: User is already verified
      if (isUserAlreadyVerifiedError(err)) {
        return;
      }

      throw new Error(
        formatAppwriteError(err, "Email verification failed. The link may be invalid or expired.")
      );
    }
  }
}

// ========================================
// STUB IMPLEMENTATION (Fallback when unconfigured)
// ========================================

export class StubAuthBackend implements AuthBackend {
  isConfigured(): boolean {
    return false;
  }

  async login(): Promise<AuthUser> {
    throw new AuthNotConfiguredError("sign in");
  }

  async register(): Promise<RegisterResult> {
    throw new AuthNotConfiguredError("create an account");
  }

  async logout(): Promise<void> {
    // No-op
  }

  async getCurrentUser(): Promise<AuthUser | null> {
    return null;
  }

  async sendPasswordRecovery(): Promise<void> {
    throw new AuthNotConfiguredError("send a password recovery email");
  }

  async completePasswordRecovery(): Promise<void> {
    throw new AuthNotConfiguredError("reset the password");
  }

  async changePassword(): Promise<void> {
    throw new AuthNotConfiguredError("change the password");
  }

  async sendEmailVerification(): Promise<void> {
    throw new AuthNotConfiguredError("send a verification email");
  }

  async completeEmailVerification(userId: string, secret: string): Promise<void> {
    if (!userId || !secret) {
      throw new Error("Missing required verification parameters: userId and secret are required.");
    }
    throw new AuthNotConfiguredError("verify the email address");
  }
}

// ========================================
// FACTORY
// ========================================

function createAuthBackend(): AuthBackend {
  if (isAppwriteConfigured) {
    return new AppwriteAuthBackend();
  }
  return new StubAuthBackend();
}

/** Singleton auth backend instance used throughout the application. */
export const authBackend = createAuthBackend();
